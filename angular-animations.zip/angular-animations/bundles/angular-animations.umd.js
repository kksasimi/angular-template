(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/animations')) :
    typeof define === 'function' && define.amd ? define('angular-animations', ['exports', '@angular/animations'], factory) :
    (global = global || self, factory(global['angular-animations'] = {}, global.ng.animations));
}(this, function (exports, animations) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    var bounce = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: animations.AUTO_STYLE, transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.2 }),
            animations.style({ transform: 'translate3d(0, -30px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.4 }),
            animations.style({ transform: 'translate3d(0, -30px, 0)', easing: 'cubic-bezier(0.755, 0.05, 0.855, 0.06)', offset: 0.43 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.755, 0.05, 0.855, 0.06)', offset: 0.53 }),
            animations.style({ transform: 'translate3d(0, -15px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.7 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.755, 0.05, 0.855, 0.06)', offset: 0.8 }),
            animations.style({ transform: 'translate3d(0, -4px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.9 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION = 1000;
    function bounceAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounce', [
            animations.transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'transform-origin': 'center bottom' }),
                    animations.useAnimation(bounce)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION
                }
            })
        ]);
    }
    function bounceOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceOnEnter', [
            animations.transition(':enter', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ visibility: 'hidden' }),
                animations.group(__spread([
                    animations.style({ 'transform-origin': 'center bottom' }),
                    animations.useAnimation(bounce)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION
                }
            })
        ]);
    }

    var flash = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: animations.AUTO_STYLE, opacity: 1, easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, easing: 'ease', offset: 0.25 }),
            animations.style({ opacity: 1, easing: 'ease', offset: 0.5 }),
            animations.style({ opacity: 0, easing: 'ease', offset: 0.75 }),
            animations.style({ opacity: 1, easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$1 = 1000;
    function flashAnimation(options) {
        return animations.trigger((options && options.anchor) || 'flash', [
            animations.transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(flash)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1
                }
            })
        ]);
    }
    function flashOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'flashOnEnter', [
            animations.transition(':enter', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ visibility: 'hidden' }),
                animations.group(__spread([
                    animations.useAnimation(flash)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1
                }
            })
        ]);
    }

    var pulse = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: animations.AUTO_STYLE, transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'scale3d({{scale}}, {{scale}}, {{scale}})', easing: 'ease', offset: 0.5 }),
            animations.style({ transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$2 = 1000;
    function pulseAnimation(options) {
        return animations.trigger((options && options.anchor) || 'pulse', [
            animations.transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(pulse)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$2,
                    scale: (options && options.scale) || 1.05
                }
            })
        ]);
    }
    function pulseOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'pulseOnEnter', [
            animations.transition(':enter', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ visibility: 'hidden' }),
                animations.group(__spread([
                    animations.useAnimation(pulse)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$2,
                    scale: (options && options.scale) || 1.05
                }
            })
        ]);
    }

    var rubberBand = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: animations.AUTO_STYLE, transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'scale3d(1.25, 0.75, 1)', easing: 'ease', offset: 0.3 }),
            animations.style({ transform: 'scale3d(0.75, 1.25, 1)', easing: 'ease', offset: 0.4 }),
            animations.style({ transform: 'scale3d(1.15, 0.85, 1)', easing: 'ease', offset: 0.5 }),
            animations.style({ transform: 'scale3d(0.95, 1.05, 1)', easing: 'ease', offset: 0.65 }),
            animations.style({ transform: 'scale3d(1.05, 0.95, 1)', easing: 'ease', offset: 0.75 }),
            animations.style({ transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$3 = 1000;
    function rubberBandAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rubberBand', [
            animations.transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(rubberBand)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$3
                }
            })
        ]);
    }
    function rubberBandOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rubberBandOnEnter', [
            animations.transition(':enter', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ visibility: 'hidden' }),
                animations.group(__spread([
                    animations.useAnimation(rubberBand)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$3
                }
            })
        ]);
    }

    var shake = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: animations.AUTO_STYLE, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0.1 }),
            animations.style({ transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0.2 }),
            animations.style({ transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0.3 }),
            animations.style({ transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0.4 }),
            animations.style({ transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0.5 }),
            animations.style({ transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0.6 }),
            animations.style({ transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0.7 }),
            animations.style({ transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0.8 }),
            animations.style({ transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0.9 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$4 = 1000;
    function shakeAnimation(options) {
        return animations.trigger((options && options.anchor) || 'shake', [
            animations.transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(shake)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$4,
                    translate: (options && options.translate) || '10px'
                }
            })
        ]);
    }
    function shakeOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'shakeOnEnter', [
            animations.transition(':enter', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ visibility: 'hidden' }),
                animations.group(__spread([
                    animations.useAnimation(shake)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$4,
                    translate: (options && options.translate) || '10px'
                }
            })
        ]);
    }

    var swing = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: animations.AUTO_STYLE, transform: 'rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'rotate3d(0, 0, 1, 15deg)', easing: 'ease', offset: 0.2 }),
            animations.style({ transform: 'rotate3d(0, 0, 1, -10deg)', easing: 'ease', offset: 0.4 }),
            animations.style({ transform: 'rotate3d(0, 0, 1, 5deg)', easing: 'ease', offset: 0.6 }),
            animations.style({ transform: 'rotate3d(0, 0, 1, -5deg)', easing: 'ease', offset: 0.8 }),
            animations.style({ transform: 'rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$5 = 1000;
    function swingAnimation(options) {
        return animations.trigger((options && options.anchor) || 'swing', [
            animations.transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'transform-origin': 'top center' }),
                    animations.useAnimation(swing)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$5
                }
            })
        ]);
    }
    function swingOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'swingOnEnter', [
            animations.transition(':enter', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ visibility: 'hidden' }),
                animations.group(__spread([
                    animations.style({ 'transform-origin': 'top center' }),
                    animations.useAnimation(swing)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$5
                }
            })
        ]);
    }

    var tada = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: animations.AUTO_STYLE, transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg)', easing: 'ease', offset: 0.1 }),
            animations.style({ transform: 'scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg)', easing: 'ease', offset: 0.2 }),
            animations.style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)', easing: 'ease', offset: 0.3 }),
            animations.style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg)', easing: 'ease', offset: 0.4 }),
            animations.style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)', easing: 'ease', offset: 0.5 }),
            animations.style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg)', easing: 'ease', offset: 0.6 }),
            animations.style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)', easing: 'ease', offset: 0.7 }),
            animations.style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg)', easing: 'ease', offset: 0.8 }),
            animations.style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)', easing: 'ease', offset: 0.9 }),
            animations.style({ transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$6 = 1000;
    function tadaAnimation(options) {
        return animations.trigger((options && options.anchor) || 'tada', [
            animations.transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(tada)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$6
                }
            })
        ]);
    }
    function tadaOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'tadaOnEnter', [
            animations.transition(':enter', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ visibility: 'hidden' }),
                animations.group(__spread([
                    animations.useAnimation(tada)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$6
                }
            })
        ]);
    }

    var wobble = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: animations.AUTO_STYLE, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg)', easing: 'ease', offset: 0.15 }),
            animations.style({ transform: 'translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg)', easing: 'ease', offset: 0.3 }),
            animations.style({ transform: 'translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg)', easing: 'ease', offset: 0.45 }),
            animations.style({ transform: 'translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg)', easing: 'ease', offset: 0.6 }),
            animations.style({ transform: 'translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg)', easing: 'ease', offset: 0.75 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$7 = 1000;
    function wobbleAnimation(options) {
        return animations.trigger((options && options.anchor) || 'wobble', [
            animations.transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(wobble)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$7
                }
            })
        ]);
    }
    function wobbleOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'wobbleOnEnter', [
            animations.transition(':enter', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ visibility: 'hidden' }),
                animations.group(__spread([
                    animations.useAnimation(wobble)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$7
                }
            })
        ]);
    }

    var jello = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: animations.AUTO_STYLE, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0.111 }),
            animations.style({ transform: 'skewX(-12.5deg) skewY(-12.5deg)', easing: 'ease', offset: 0.222 }),
            animations.style({ transform: 'skewX(6.25deg) skewY(6.25deg)', easing: 'ease', offset: 0.333 }),
            animations.style({ transform: 'skewX(-3.125deg) skewY(-3.125deg)', easing: 'ease', offset: 0.444 }),
            animations.style({ transform: 'skewX(1.5625deg) skewY(1.5625deg)', easing: 'ease', offset: 0.555 }),
            animations.style({ transform: 'skewX(-0.78125deg) skewY(-0.78125deg)', easing: 'ease', offset: 0.666 }),
            animations.style({ transform: 'skewX(0.390625deg) skewY(0.390625deg)', easing: 'ease', offset: 0.777 }),
            animations.style({ transform: 'skewX(-0.1953125deg) skewY(-0.1953125deg)', easing: 'ease', offset: 0.888 }),
            animations.style({ transform: 'skewX(0deg) skewY(0deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$8 = 1000;
    function jelloAnimation(options) {
        return animations.trigger((options && options.anchor) || 'jello', [
            animations.transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'transform-origin': 'center' }),
                    animations.useAnimation(jello)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$8
                }
            })
        ]);
    }
    function jelloOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'jelloOnEnter', [
            animations.transition(':enter', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ visibility: 'hidden' }),
                animations.group(__spread([
                    animations.style({ 'transform-origin': 'center' }),
                    animations.useAnimation(jello)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$8
                }
            })
        ]);
    }

    var heartBeat = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: animations.AUTO_STYLE, transform: 'scale(1)', easing: 'ease-in-out', offset: 0 }),
            animations.style({ transform: 'scale({{scale}})', easing: 'ease-in-out', offset: 0.14 }),
            animations.style({ transform: 'scale(1)', easing: 'ease-in-out', offset: 0.28 }),
            animations.style({ transform: 'scale({{scale}})', easing: 'ease-in-out', offset: 0.42 }),
            animations.style({ transform: 'scale(1)', easing: 'ease-in-out', offset: 0.7 })
        ]))
    ]);
    var DEFAULT_DURATION$9 = 1300;
    var DEFAULT_SCALE = 1.3;
    function heartBeatAnimation(options) {
        return animations.trigger((options && options.anchor) || 'heartBeat', [
            animations.transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(heartBeat)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$9,
                    scale: (options && options.scale) || DEFAULT_SCALE
                }
            })
        ]);
    }
    function heartBeatOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'heartBeatOnEnter', [
            animations.transition(':enter', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ visibility: 'hidden' }),
                animations.group(__spread([
                    animations.useAnimation(heartBeat)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$9,
                    scale: (options && options.scale) || DEFAULT_SCALE
                }
            })
        ]);
    }

    var headShake = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: animations.AUTO_STYLE, transform: 'translateX(0)', easing: 'ease-in-out', offset: 0 }),
            animations.style({ transform: 'translateX(-6px) rotateY(-9deg)', easing: 'ease-in-out', offset: 0.065 }),
            animations.style({ transform: 'translateX(5px) rotateY(7deg)', easing: 'ease-in-out', offset: 0.185 }),
            animations.style({ transform: 'translateX(-3px) rotateY(-5deg)', easing: 'ease-in-out', offset: 0.315 }),
            animations.style({ transform: 'translateX(2px) rotateY(3deg)', easing: 'ease-in-out', offset: 0.435 }),
            animations.style({ transform: 'translateX(0)', easing: 'ease-in-out', offset: 0.5 })
        ]))
    ]);
    var DEFAULT_DURATION$a = 1000;
    function headShakeAnimation(options) {
        return animations.trigger((options && options.anchor) || 'headShake', [
            animations.transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(headShake)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$a
                }
            })
        ]);
    }
    function headShakeOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'headShakeOnEnter', [
            animations.transition(':enter', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ visibility: 'hidden' }),
                animations.group(__spread([
                    animations.useAnimation(headShake)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$a
                }
            })
        ]);
    }

    var bounceIn = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'scale3d(0.3, 0.3, 0.3)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
            animations.style({ transform: 'scale3d(1.1, 1.1, 1.1)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.2 }),
            animations.style({ transform: 'scale3d(0.9, 0.9, 0.9)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.4 }),
            animations.style({ transform: 'scale3d(1.03, 1.03, 1.03)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
            animations.style({ transform: 'scale3d(0.97, 0.97, 0.97)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.8 }),
            animations.style({ transform: 'scale3d(1, 1, 1)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
        ])),
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
            animations.style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
            animations.style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
        ]))
    ]));
    var DEFAULT_DURATION$b = 750;
    function bounceInAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceIn', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceIn)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$b
                }
            })
        ]);
    }
    function bounceInOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceInOnEnter', [
            animations.transition(':enter', animations.animation(__spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceIn)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []))), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$b
                }
            })
        ]);
    }

    var bounceInDown = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'translate3d(0, -{{translate}}, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
            animations.style({ transform: 'translate3d(0, 25px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
            animations.style({ transform: 'translate3d(0, -10px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.75 }),
            animations.style({ transform: 'translate3d(0, 5px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.9 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
        ])),
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
            animations.style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
            animations.style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
        ]))
    ]));
    var DEFAULT_DURATION$c = 1000;
    function bounceInDownAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceInDown', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceInDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$c,
                    translate: (options && options.translate) || '3000px'
                }
            })
        ]);
    }
    function bounceInDownOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceInDownOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceInDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$c,
                    translate: (options && options.translate) || '3000px'
                }
            })
        ]);
    }

    var bounceInLeft = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
            animations.style({ transform: 'translate3d(25px, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
            animations.style({ transform: 'translate3d(-10px, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.75 }),
            animations.style({ transform: 'translate3d(5px, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.9 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
        ])),
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
            animations.style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
            animations.style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
        ]))
    ]));
    var DEFAULT_DURATION$d = 1000;
    function bounceInLeftAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceInLeft', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceInLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$d,
                    translate: (options && options.translate) || '3000px'
                }
            })
        ]);
    }
    function bounceInLeftOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceInLeftOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceInLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$d,
                    translate: (options && options.translate) || '3000px'
                }
            })
        ]);
    }

    var bounceInRight = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'translate3d({{translate}}, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
            animations.style({ transform: 'translate3d(-25px, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
            animations.style({ transform: 'translate3d(10px, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.75 }),
            animations.style({ transform: 'translate3d(-5px, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.9 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
        ])),
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
            animations.style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
            animations.style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
        ]))
    ]));
    var DEFAULT_DURATION$e = 1000;
    function bounceInRightAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceInRight', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceInRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$e,
                    translate: (options && options.translate) || '3000px'
                }
            })
        ]);
    }
    function bounceInRightOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceInRightOnEnter', [
            animations.transition(':enter', __spread([
                // style({ background: 'red' }),
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceInRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$e,
                    translate: (options && options.translate) || '3000px'
                }
            })
        ]);
    }

    var bounceInUp = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'translate3d(0, {{translate}}, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
            animations.style({ transform: 'translate3d(0, -20px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
            animations.style({ transform: 'translate3d(0, 10px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.75 }),
            animations.style({ transform: 'translate3d(0, -5px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.9 }),
            animations.style({ transform: 'translate3d(0, -5px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
        ])),
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
            animations.style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
            animations.style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
        ]))
    ]));
    var DEFAULT_DURATION$f = 1000;
    function bounceInUpAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceInUp', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceInUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$f,
                    translate: (options && options.translate) || '3000px'
                }
            })
        ]);
    }
    function bounceInUpOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceInUpOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceInUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$f,
                    translate: (options && options.translate) || '3000px'
                }
            })
        ]);
    }

    var bounceOut = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'scale3d(0.9, 0.9, 0.9)', easing: 'ease', offset: 0.2 }),
            animations.style({ transform: 'scale3d(1.1, 1.1, 1.1)', easing: 'ease', offset: 0.5 }),
            animations.style({ transform: 'scale3d(1.1, 1.1, 1.1)', easing: 'ease', offset: 0.55 }),
            animations.style({ transform: 'scale3d(0.3, 0.3, 0.3)', easing: 'ease', offset: 1 })
        ])),
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, easing: 'ease', offset: 0.55 }),
            animations.style({ opacity: 0, easing: 'ease', offset: 1 })
        ]))
    ]));
    var DEFAULT_DURATION$g = 750;
    function bounceOutAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceOut', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceOut)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$g
                }
            })
        ]);
    }
    function bounceOutOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceOutOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceOut)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$g
                }
            })
        ]);
    }

    var bounceOutDown = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d(0, 10px, 0)', easing: 'ease', offset: 0.2 }),
            animations.style({ transform: 'translate3d(0, -20px, 0)', easing: 'ease', offset: 0.4 }),
            animations.style({ transform: 'translate3d(0, -20px, 0)', easing: 'ease', offset: 0.45 }),
            animations.style({ transform: 'translate3d(0, {{translate}}, 0)', easing: 'ease', offset: 1 })
        ])),
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, easing: 'ease', offset: 0.45 }),
            animations.style({ opacity: 0, easing: 'ease', offset: 1 })
        ]))
    ]));
    var DEFAULT_DURATION$h = 1000;
    function bounceOutDownAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceOutDown', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceOutDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$h,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }
    function bounceOutDownOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceOutDownOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceOutDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$h,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }

    var bounceOutLeft = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'translate3d(20px, 0, 0)', easing: 'ease', offset: 0.2 }),
            animations.style({ opacity: 0, transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$i = 1000;
    function bounceOutLeftAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceOutLeft', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceOutLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$i,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }
    function bounceOutLeftOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceOutLeftOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceOutLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$i,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }

    var bounceOutRight = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'translate3d(-20px, 0, 0)', easing: 'ease', offset: 0.2 }),
            animations.style({ opacity: 0, transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$j = 1000;
    function bounceOutRightAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceOutRight', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceOutRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$j,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }
    function bounceOutRightOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceOutRightOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceOutRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$j,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }

    var bounceOutUp = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d(0, -10px, 0)', easing: 'ease', offset: 0.2 }),
            animations.style({ transform: 'translate3d(0, 20px, 0)', easing: 'ease', offset: 0.4 }),
            animations.style({ transform: 'translate3d(0, 20px, 0)', easing: 'ease', offset: 0.45 }),
            animations.style({ transform: 'translate3d(0, -{{translate}}, 0)', easing: 'ease', offset: 1 })
        ])),
        animations.animation([
            animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
                animations.style({ opacity: 1, easing: 'ease', offset: 0 }),
                animations.style({ opacity: 1, easing: 'ease', offset: 0.45 }),
                animations.style({ opacity: 0, easing: 'ease', offset: 1 })
            ]))
        ])
    ]));
    var DEFAULT_DURATION$k = 1000;
    function bounceOutUpAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceOutUp', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceOutUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$k,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }
    function bounceOutUpOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'bounceOutUpOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(bounceOutUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$k,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }

    var fadeIn = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([animations.style({ visibility: 'visible', opacity: 0, easing: 'ease', offset: 0 }), animations.style({ opacity: 1, easing: 'ease', offset: 1 })]))
    ]);
    var DEFAULT_DURATION$l = 1000;
    function fadeInAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeIn', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeIn)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$l
                }
            })
        ]);
    }
    function fadeInOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeIn)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$l
                }
            })
        ]);
    }

    var fadeInDown = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'translate3d(0, -{{translate}}, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$m = 1000;
    function fadeInDownAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInDown', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$m,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function fadeInDownOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInDownOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$m,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var fadeInDownBig = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'translate3d(0, -{{translate}}, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$n = 1000;
    function fadeInDownBigAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInDownBig', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInDownBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$n,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }
    function fadeInDownBigOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInDownBigOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInDownBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$n,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }

    var fadeInLeft = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$o = 1000;
    function fadeInLeftAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInLeft', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$o,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function fadeInLeftOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInLeftOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$o,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var fadeInLeftBig = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$p = 1000;
    function fadeInLeftBigAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInLeftBig', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInLeftBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$p,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }
    function fadeInLeftBigOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInLeftBigOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInLeftBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$p,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }

    var fadeInRight = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$q = 1000;
    function fadeInRightAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInRight', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$q,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function fadeInRightOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInRightOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$q,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var fadeInRightBig = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$r = 1000;
    function fadeInRightBigAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInRightBig', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInRightBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$r,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }
    function fadeInRightBigOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInRightBigOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInRightBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$r,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }

    var fadeInUp = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'translate3d(0, {{translate}}, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$s = 1000;
    function fadeInUpAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInUp', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$s,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function fadeInUpOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInUpOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$s,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var fadeInUpBig = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'translate3d(0, {{translate}}, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$t = 1000;
    function fadeInUpBigAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInUpBig', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInUpBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$t,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }
    function fadeInUpBigOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInUpBigOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInUpBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$t,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }

    var fadeOut = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([animations.style({ opacity: 1, easing: 'ease', offset: 0 }), animations.style({ opacity: 0, easing: 'ease', offset: 1 })]))
    ]);
    var DEFAULT_DURATION$u = 1000;
    function fadeOutAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOut', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOut)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$u
                }
            })
        ]);
    }
    function fadeOutOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOut)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$u
                }
            })
        ]);
    }

    var fadeOutDown = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'translate3d(0, {{translate}}, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$v = 1000;
    function fadeOutDownAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutDown', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$v,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function fadeOutDownOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutDownOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$v,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var fadeOutDownBig = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'translate3d(0, {{translate}}, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$w = 1000;
    function fadeOutDownBigAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutDownBig', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutDownBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$w,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }
    function fadeOutDownBigOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutDownBigOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutDownBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$w,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }

    var fadeOutLeft = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$x = 1000;
    function fadeOutLeftAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutLeft', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$x,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function fadeOutLeftOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutLeftOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$x,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var fadeOutLeftBig = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$y = 1000;
    function fadeOutLeftBigAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutLeftBig', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutLeftBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$y,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }
    function fadeOutLeftBigOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutLeftBigOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutLeftBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$y,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }

    var fadeOutRight = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$z = 1000;
    function fadeOutRightAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutRight', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$z,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function fadeOutRightOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutRightOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$z,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var fadeOutRightBig = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$A = 1000;
    function fadeOutRightBigAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutRightBig', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutRightBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$A,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }
    function fadeOutRightBigOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutRightBigOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutRightBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$A,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }

    var fadeOutUp = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'translate3d(0, -{{translate}}, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$B = 1000;
    function fadeOutUpAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutUp', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$B,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function fadeOutUpOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutUpOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$B,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var fadeOutUpBig = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'translate3d(0, -{{translate}}, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$C = 1000;
    function fadeOutUpBigAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutUpBig', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutUpBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$C,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }
    function fadeOutUpBigOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutUpBigOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutUpBig)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$C,
                    translate: (options && options.translate) || '2000px'
                }
            })
        ]);
    }

    var flip = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({
                transform: 'perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 0) rotate3d(0, 1, 0, -360deg)',
                easing: 'ease-out',
                offset: 0
            }),
            animations.style({
                transform: 'perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg)',
                easing: 'ease-out',
                offset: 0.4
            }),
            animations.style({
                transform: 'perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg)',
                easing: 'ease-out',
                offset: 0.5
            }),
            animations.style({
                transform: 'perspective(400px) scale3d(0.95, 0.95, 0.95) translate3d(0, 0, 0) rotate3d(0, 1, 0, 0deg)',
                easing: 'ease-in',
                offset: 0.8
            }),
            animations.style({ transform: 'perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 0) rotate3d(0, 1, 0, 0deg)', easing: 'ease-in', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$D = 1000;
    function flipAnimation(options) {
        return animations.trigger((options && options.anchor) || 'flip', [
            animations.transition('0 <=> 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'backface-visibility': 'visible' }),
                    animations.useAnimation(flip)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$D
                }
            })
        ]);
    }
    function flipOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'flipOnEnter', [
            animations.transition(':enter', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'backface-visibility': 'visible' }),
                    animations.useAnimation(flip)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$D
                }
            })
        ]);
    }

    var flipInX = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({
                visibility: 'visible',
                transform: 'perspective(400px) rotate3d(1, 0, 0, {{degrees}}deg)',
                opacity: 0,
                easing: 'ease-in',
                offset: 0
            }),
            animations.style({ transform: 'perspective(400px) rotate3d(1, 0, 0, -20deg)', opacity: 0.5, easing: 'ease-in', offset: 0.4 }),
            animations.style({ transform: 'perspective(400px) rotate3d(1, 0, 0, 10deg)', opacity: 1, easing: 'ease-in', offset: 0.6 }),
            animations.style({ transform: 'perspective(400px) rotate3d(1, 0, 0, -5deg)', easing: 'ease', offset: 0.8 }),
            animations.style({ transform: 'perspective(400px)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$E = 1000;
    function flipInXAnimation(options) {
        return animations.trigger((options && options.anchor) || 'flipInX', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'backface-visibility': 'visible' }),
                    animations.useAnimation(flipInX)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$E,
                    degrees: (options && options.degrees) || 90
                }
            })
        ]);
    }
    function flipInXOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'flipInXOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'backface-visibility': 'visible' }),
                    animations.useAnimation(flipInX)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$E,
                    degrees: (options && options.degrees) || 90
                }
            })
        ]);
    }

    var flipInY = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({
                visibility: 'visible',
                transform: 'perspective(400px) rotate3d(0, 1, 0, {{degrees}}deg)',
                opacity: 0,
                easing: 'ease-in',
                offset: 0
            }),
            animations.style({ transform: 'perspective(400px) rotate3d(0, 1, 0, -20deg)', opacity: 0.5, easing: 'ease-in', offset: 0.4 }),
            animations.style({ transform: 'perspective(400px) rotate3d(0, 1, 0, 10deg)', opacity: 1, easing: 'ease-in', offset: 0.6 }),
            animations.style({ transform: 'perspective(400px) rotate3d(0, 1, 0, -5deg)', easing: 'ease', offset: 0.8 }),
            animations.style({ transform: 'perspective(400px)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$F = 1000;
    function flipInYAnimation(options) {
        return animations.trigger((options && options.anchor) || 'flipInY', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'backface-visibility': 'visible' }),
                    animations.useAnimation(flipInY)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$F,
                    degrees: (options && options.degrees) || 90
                }
            })
        ]);
    }
    function flipInYOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'flipInYOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'backface-visibility': 'visible' }),
                    animations.useAnimation(flipInY)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$F,
                    degrees: (options && options.degrees) || 90
                }
            })
        ]);
    }

    var flipOutX = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'perspective(400px)', opacity: 1, easing: 'ease', offset: 0 }),
            animations.style({ transform: 'perspective(400px) rotate3d(1, 0, 0, -20deg)', opacity: 1, easing: 'ease', offset: 0.3 }),
            animations.style({ transform: 'perspective(400px) rotate3d(1, 0, 0, {{degrees}}deg)', opacity: 0, easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$G = 750;
    function flipOutXAnimation(options) {
        return animations.trigger((options && options.anchor) || 'flipOutX', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'backface-visibility': 'visible' }),
                    animations.useAnimation(flipOutX)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$G,
                    degrees: (options && options.degrees) || 90
                }
            })
        ]);
    }
    function flipOutXOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'flipOutXOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'backface-visibility': 'visible' }),
                    animations.useAnimation(flipOutX)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$G,
                    degrees: (options && options.degrees) || 90
                }
            })
        ]);
    }

    var flipOutY = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'perspective(400px)', opacity: 1, easing: 'ease', offset: 0 }),
            animations.style({ transform: 'perspective(400px) rotate3d(0, 1, 0, -15deg)', opacity: 1, easing: 'ease', offset: 0.3 }),
            animations.style({ transform: 'perspective(400px) rotate3d(0, 1, 0, {{degrees}}deg)', opacity: 0, easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$H = 750;
    function flipOutYAnimation(options) {
        return animations.trigger((options && options.anchor) || 'flipOutY', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'backface-visibility': 'visible' }),
                    animations.useAnimation(flipOutY)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$H,
                    degrees: (options && options.degrees) || 90
                }
            })
        ]);
    }
    function flipOutYOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'flipOutYOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ 'backface-visibility': 'visible' }),
                    animations.useAnimation(flipOutY)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$H,
                    degrees: (options && options.degrees) || 90
                }
            })
        ]);
    }

    var lightSpeedIn = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({
                visibility: 'visible',
                opacity: 0,
                transform: 'translate3d({{translate}}, 0, 0) skewX(-30deg)',
                easing: 'ease-out',
                offset: 0
            }),
            animations.style({ opacity: 1, transform: 'skewX(20deg)', easing: 'ease-out', offset: 0.6 }),
            animations.style({ opacity: 1, transform: 'skewX(-5deg)', easing: 'ease-out', offset: 0.8 }),
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease-out', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$I = 1000;
    function lightSpeedInAnimation(options) {
        return animations.trigger((options && options.anchor) || 'lightSpeedIn', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(lightSpeedIn)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$I,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function lightSpeedInOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'lightSpeedInOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(lightSpeedIn)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$I,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var lightSpeedOut = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, easing: 'ease-in', offset: 0 }),
            animations.style({ opacity: 0, transform: 'translate3d({{translate}}, 0, 0) skewX(30deg)', easing: 'ease-in', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$J = 1000;
    function lightSpeedOutAnimation(options) {
        return animations.trigger((options && options.anchor) || 'lightSpeedOut', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(lightSpeedOut)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$J,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function lightSpeedOutOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'lightSpeedOutOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(lightSpeedOut)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$J,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var rotateIn = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'rotate({{degrees}}deg)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'rotate(0deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$K = 1000;
    function rotateInAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateIn', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'center' }),
                animations.group(__spread([
                    animations.useAnimation(rotateIn)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$K,
                    degrees: (options && options.degrees) || -200
                }
            })
        ]);
    }
    function rotateInOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateInOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'center' }),
                animations.group(__spread([
                    animations.useAnimation(rotateIn)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$K,
                    degrees: (options && options.degrees) || -200
                }
            })
        ]);
    }

    var rotateInDownLeft = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$L = 1000;
    function rotateInDownLeftAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateInDownLeft', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'left bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateInDownLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$L,
                    degrees: (options && options.degrees) || -45
                }
            })
        ]);
    }
    function rotateInDownLeftOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateInDownLeftOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'left bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateInDownLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$L,
                    degrees: (options && options.degrees) || -45
                }
            })
        ]);
    }

    var rotateInDownRight = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$M = 1000;
    function rotateInDownRightAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateInDownRight', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'right bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateInDownRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$M,
                    degrees: (options && options.degrees) || 45
                }
            })
        ]);
    }
    function rotateInDownRightOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateInDownRightOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'right bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateInDownRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$M,
                    degrees: (options && options.degrees) || 45
                }
            })
        ]);
    }

    var rotateInUpLeft = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$N = 1000;
    function rotateInUpLeftAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateInUpLeft', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'left bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateInUpLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$N,
                    degrees: (options && options.degrees) || 45
                }
            })
        ]);
    }
    function rotateInUpLeftOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateInUpLeftOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'left bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateInUpLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$N,
                    degrees: (options && options.degrees) || 45
                }
            })
        ]);
    }

    var rotateInUpRight = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, transform: 'rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$O = 1000;
    function rotateInUpRightAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateInUpRight', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'right bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateInUpRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$O,
                    degrees: (options && options.degrees) || -90
                }
            })
        ]);
    }
    function rotateInUpRightOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateInUpRightOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'right bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateInUpRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$O,
                    degrees: (options && options.degrees) || -90
                }
            })
        ]);
    }

    var rotateOut = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'rotate({{degrees}}deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$P = 1000;
    function rotateOutAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateOut', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'center' }),
                animations.group(__spread([
                    animations.useAnimation(rotateOut)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$P,
                    degrees: (options && options.degrees) || 200
                }
            })
        ]);
    }
    function rotateOutOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateOutOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'center' }),
                animations.group(__spread([
                    animations.useAnimation(rotateOut)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$P,
                    degrees: (options && options.degrees) || 200
                }
            })
        ]);
    }

    var rotateOutDownLeft = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$Q = 1000;
    function rotateOutDownLeftAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateOutDownLeft', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'left bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateOutDownLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$Q,
                    degrees: (options && options.degrees) || 45
                }
            })
        ]);
    }
    function rotateOutDownLeftOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateOutDownLeftOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'left bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateOutDownLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$Q,
                    degrees: (options && options.degrees) || 45
                }
            })
        ]);
    }

    var rotateOutDownRight = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$R = 1000;
    function rotateOutDownRightAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateOutDownRight', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'right bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateOutDownRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$R,
                    degrees: (options && options.degrees) || -45
                }
            })
        ]);
    }
    function rotateOutDownRightOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateOutDownRightOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'right bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateOutDownRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$R,
                    degrees: (options && options.degrees) || -45
                }
            })
        ]);
    }

    var rotateOutUpLeft = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$S = 1000;
    function rotateOutUpLeftAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateOutUpLeft', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'left bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateOutUpLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$S,
                    degrees: (options && options.degrees) || -45
                }
            })
        ]);
    }
    function rotateOutUpLeftOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateOutUpLeftOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'left bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateOutUpLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$S,
                    degrees: (options && options.degrees) || -45
                }
            })
        ]);
    }

    var rotateOutUpRight = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$T = 1000;
    function rotateOutUpRightAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateOutUpRight', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'right bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateOutUpRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$T,
                    degrees: (options && options.degrees) || 90
                }
            })
        ]);
    }
    function rotateOutUpRightOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotateOutUpRightOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.style({ 'transform-origin': 'right bottom' }),
                animations.group(__spread([
                    animations.useAnimation(rotateOutUpRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$T,
                    degrees: (options && options.degrees) || 90
                }
            })
        ]);
    }

    var slideInDown = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', transform: 'translate3d(0, -{{translate}}, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$U = 1000;
    function slideInDownAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideInDown', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ visibility: 'visible' }),
                    animations.useAnimation(slideInDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$U,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function slideInDownOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideInDownOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(slideInDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$U,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var slideInLeft = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$V = 1000;
    function slideInLeftAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideInLeft', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ visibility: 'visible' }),
                    animations.useAnimation(slideInLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$V,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function slideInLeftOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideInLeftOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(slideInLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$V,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var slideInRight = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$W = 1000;
    function slideInRightAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideInRight', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ visibility: 'visible' }),
                    animations.useAnimation(slideInRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$W,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function slideInRightOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideInRightOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(slideInRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$W,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var slideInUp = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', transform: 'translate3d(0, {{translate}}, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$X = 1000;
    function slideInUpAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideInUp', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.style({ visibility: 'visible' }),
                    animations.useAnimation(slideInUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$X,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function slideInUpOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideInUpOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(slideInUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$X,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var slideOutDown = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d(0, {{translate}}, 0)', visibility: 'hidden', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$Y = 1000;
    function slideOutDownAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideOutDown', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(slideOutDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$Y,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function slideOutDownOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideOutDownOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(slideOutDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$Y,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var slideOutLeft = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d(-{{translate}}, 0, 0)', visibility: 'hidden', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$Z = 1000;
    function slideOutLeftAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideOutLeft', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(slideOutLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$Z,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function slideOutLeftOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideOutLeftOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(slideOutLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$Z,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var slideOutRight = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d({{translate}}, 0, 0)', visibility: 'hidden', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$_ = 1000;
    function slideOutRightAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideOutRight', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(slideOutRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$_,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function slideOutRightOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideOutRightOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(slideOutRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$_,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var slideOutUp = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'translate3d(0, -{{translate}}, 0)', visibility: 'hidden', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$$ = 1000;
    function slideOutUpAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideOutUp', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(slideOutUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$$,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function slideOutUpOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'slideOutUpOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(slideOutUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$$,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var zoomIn = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 0, easing: 'ease', offset: 0 }),
            animations.style({ opacity: 1, easing: 'ease', offset: 0.5 }),
            animations.style({ opacity: 1, easing: 'ease', offset: 1 })
        ])),
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ visibility: 'visible', transform: 'scale3d(0.3, 0.3, 0.3)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 1 })
        ]))
    ]));
    var DEFAULT_DURATION$10 = 1000;
    function zoomInAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomIn', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomIn)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$10
                }
            })
        ]);
    }
    function zoomInOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomInOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomIn)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$10
                }
            })
        ]);
    }

    var zoomInDown = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({
                visibility: 'visible',
                opacity: 0,
                transform: 'scale3d(0.1, 0.1, 0.1) translate3d(0, -1000px, 0)',
                easing: 'ease',
                offset: 0
            }),
            animations.style({
                opacity: 1,
                transform: 'scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0)',
                easing: 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
                offset: 0.6
            }),
            animations.style({ opacity: 1, transform: 'scale3d(1, 1, 1) translate3d(0, 0, 0)', easing: 'cubic-bezier(0.175, 0.885, 0.32, 1)', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$11 = 1000;
    function zoomInDownAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomInDown', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomInDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$11
                }
            })
        ]);
    }
    function zoomInDownOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomInDownOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomInDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$11
                }
            })
        ]);
    }

    var zoomInLeft = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({
                visibility: 'visible',
                opacity: 0,
                transform: 'scale3d(0.1, 0.1, 0.1) translate3d(-3000px, 0, 0)',
                easing: 'ease',
                offset: 0
            }),
            animations.style({
                opacity: 1,
                transform: 'scale3d(0.475, 0.475, 0.475) translate3d(10px, 0, 0)',
                easing: 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
                offset: 0.6
            }),
            animations.style({ opacity: 1, transform: 'scale3d(1, 1, 1) translate3d(0, 0, 0)', easing: 'cubic-bezier(0.175, 0.885, 0.32, 1)', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$12 = 1000;
    function zoomInLeftAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomInLeft', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomInLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$12
                }
            })
        ]);
    }
    function zoomInLeftOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomInLeftOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomInLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$12
                }
            })
        ]);
    }

    var zoomInRight = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({
                visibility: 'visible',
                opacity: 0,
                transform: 'scale3d(0.1, 0.1, 0.1) translate3d(1000px, 0, 0)',
                easing: 'ease',
                offset: 0
            }),
            animations.style({
                opacity: 1,
                transform: 'scale3d(0.475, 0.475, 0.475) translate3d(-10px, 0, 0)',
                easing: 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
                offset: 0.6
            }),
            animations.style({ opacity: 1, transform: 'scale3d(1, 1, 1) translate3d(0, 0, 0)', easing: 'cubic-bezier(0.175, 0.885, 0.32, 1)', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$13 = 1000;
    function zoomInRightAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomInRight', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomInRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$13
                }
            })
        ]);
    }
    function zoomInRightOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomInRightOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomInRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$13
                }
            })
        ]);
    }

    var zoomInUp = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({
                visibility: 'visible',
                opacity: 0,
                transform: 'scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0)',
                easing: 'ease',
                offset: 0
            }),
            animations.style({
                opacity: 1,
                transform: 'scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0)',
                easing: 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
                offset: 0.6
            }),
            animations.style({ opacity: 1, transform: 'scale3d(1, 1, 1) translate3d(0, 0, 0)', easing: 'cubic-bezier(0.175, 0.885, 0.32, 1)', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$14 = 1000;
    function zoomInUpAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomInUp', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomInUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$14
                }
            })
        ]);
    }
    function zoomInUpOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomInUpOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomInUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$14
                }
            })
        ]);
    }

    var zoomOut = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'scale3d(0.3, 0.3, 0.3)', easing: 'ease', offset: 0.5 }),
            animations.style({ opacity: 0, easing: 'ease', offset: 1 })
        ])),
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 0 }),
            animations.style({ transform: 'scale3d(0.3, 0.3, 0.3)', easing: 'ease', offset: 0.5 })
        ]))
    ]));
    var DEFAULT_DURATION$15 = 1000;
    function zoomOutAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomOut', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomOut)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$15
                }
            })
        ]);
    }
    function zoomOutOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomOutOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomOut)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$15
                }
            })
        ]);
    }

    var zoomOutDown = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({
                'transform-origin': 'center bottom',
                opacity: 1,
                transform: 'scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0)',
                easing: 'ease',
                offset: 0.4
            }),
            animations.style({
                'transform-origin': 'center bottom',
                opacity: 0,
                transform: 'scale3d(0.1, 0.1, 0.1) translate3d(0, 2000px, 0)',
                easing: 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
                offset: 1
            })
        ]))
    ]);
    var DEFAULT_DURATION$16 = 1000;
    function zoomOutDownAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomOutDown', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomOutDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$16
                }
            })
        ]);
    }
    function zoomOutDownOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomOutDownOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomOutDown)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$16
                }
            })
        ]);
    }

    var zoomOutLeft = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'scale3d(0.475, 0.475, 0.475) translate3d(42px, 0, 0)', easing: 'ease', offset: 0.4 }),
            animations.style({ opacity: 0, transform: 'scale3d(0.1, 0.1, 0.1) translate3d(-2000px, 0, 0)', easing: 'ease', offset: 1 })
        ])),
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([animations.style({ 'transform-origin': 'center center', offset: 0 }), animations.style({ 'transform-origin': 'left center', offset: 0.4 })]))
    ]));
    var DEFAULT_DURATION$17 = 1000;
    function zoomOutLeftAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomOutLeft', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomOutLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$17
                }
            })
        ]);
    }
    function zoomOutLeftOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomOutLeftOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomOutLeft)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$17
                }
            })
        ]);
    }

    var zoomOutRight = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'scale3d(0.475, 0.475, 0.475) translate3d(-42px, 0, 0)', easing: 'ease', offset: 0.4 }),
            animations.style({ opacity: 0, transform: 'scale3d(0.1, 0.1, 0.1) translate3d(2000px, 0, 0)', easing: 'ease', offset: 1 })
        ])),
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([animations.style({ 'transform-origin': 'center center', offset: 0 }), animations.style({ 'transform-origin': 'right center', offset: 0.4 })]))
    ]));
    var DEFAULT_DURATION$18 = 1000;
    function zoomOutRightAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomOutRight', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomOutRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$18
                }
            })
        ]);
    }
    function zoomOutRightOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomOutRightOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomOutRight)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$18
                }
            })
        ]);
    }

    var zoomOutUp = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({
                'transform-origin': 'center bottom',
                opacity: 1,
                transform: 'scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0)',
                easing: 'ease',
                offset: 0.4
            }),
            animations.style({
                'transform-origin': 'center bottom',
                opacity: 0,
                transform: 'scale3d(0.1, 0.1, 0.1) translate3d(0, -2000px, 0)',
                easing: 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
                offset: 1
            })
        ]))
    ]);
    var DEFAULT_DURATION$19 = 1000;
    function zoomOutUpAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomOutUp', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomOutUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$19
                }
            })
        ]);
    }
    function zoomOutUpOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'zoomOutUpOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(zoomOutUp)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$19
                }
            })
        ]);
    }

    var hinge = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, 'transform-origin': 'top left', transform: 'translate3d(0, 0, 0)', easing: 'ease-in-out', offset: 0 }),
            animations.style({ opacity: 1, 'transform-origin': 'top left', transform: 'rotate3d(0, 0, 1, 80deg)', easing: 'ease-in-out', offset: 0.2 }),
            animations.style({ opacity: 1, 'transform-origin': 'top left', transform: 'rotate3d(0, 0, 1, 60deg)', easing: 'ease-in-out', offset: 0.4 }),
            animations.style({ opacity: 1, 'transform-origin': 'top left', transform: 'rotate3d(0, 0, 1, 80deg)', easing: 'ease-in-out', offset: 0.6 }),
            animations.style({ opacity: 1, 'transform-origin': 'top left', transform: 'rotate3d(0, 0, 1, 60deg)', easing: 'ease-in-out', offset: 0.8 }),
            animations.style({ opacity: 0, 'transform-origin': 'top left', transform: 'translate3d(0, 700px, 0)', easing: 'ease-in-out', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$1a = 2000;
    function hingeAnimation(options) {
        return animations.trigger((options && options.anchor) || 'hinge', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(hinge)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1a
                }
            })
        ]);
    }
    function hingeOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'hingeOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(hinge)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1a
                }
            })
        ]);
    }

    var jackInTheBox = animations.animation(animations.group([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ 'transform-origin': 'center bottom', transform: 'scale(0.1) rotate(30deg)', easing: 'ease', offset: 0 }),
            animations.style({ 'transform-origin': 'center bottom', transform: 'rotate(-10deg)', easing: 'ease', offset: 0.5 }),
            animations.style({ 'transform-origin': 'center bottom', transform: 'rotate(3deg)', easing: 'ease', offset: 0.7 }),
            animations.style({ 'transform-origin': 'center bottom', transform: 'scale(1)', easing: 'ease', offset: 1 })
        ])),
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([animations.style({ visibility: 'visible', opacity: 0, offset: 0 }), animations.style({ opacity: 1, offset: 1 })]))
    ]));
    var DEFAULT_DURATION$1b = 1000;
    function jackInTheBoxAnimation(options) {
        return animations.trigger((options && options.anchor) || 'jackInTheBox', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(jackInTheBox)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1b
                }
            })
        ]);
    }
    function jackInTheBoxOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'jackInTheBoxOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(jackInTheBox)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1b
                }
            })
        ]);
    }

    var rollIn = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({
                visibility: 'visible',
                opacity: 0,
                transform: 'translate3d({{translate}}, 0, 0) rotate3d(0, 0, 1, {{degrees}}deg)',
                easing: 'ease',
                offset: 0
            }),
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0) rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$1c = 1000;
    function rollInAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rollIn', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(rollIn)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1c,
                    degrees: (options && options.degrees) || -120,
                    translate: (options && options.translate) || '-100%'
                }
            })
        ]);
    }
    function rollInOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rollInOnEnter', [
            animations.transition(':enter', __spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(rollIn)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1c,
                    degrees: (options && options.degrees) || -120,
                    translate: (options && options.translate) || '-100%'
                }
            })
        ]);
    }

    var rollOut = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
            animations.style({ opacity: 1, transform: 'translate3d(0, 0, 0) rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 0 }),
            animations.style({ opacity: 0, transform: 'translate3d({{translate}}, 0, 0) rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 1 })
        ]))
    ]);
    var DEFAULT_DURATION$1d = 1000;
    function rollOutAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rollOut', [
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(rollOut)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1d,
                    degrees: (options && options.degrees) || 120,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }
    function rollOutOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rollOutOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(rollOut)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1d,
                    degrees: (options && options.degrees) || 120,
                    translate: (options && options.translate) || '100%'
                }
            })
        ]);
    }

    var DEFAULT_DURATION$1e = 200;
    function collapseAnimation(options) {
        return animations.trigger((options && options.anchor) || 'collapse', [
            animations.state('1', animations.style({
                height: '0',
                visibility: 'hidden',
                overflow: 'hidden'
            })),
            animations.state('0', animations.style({
                height: animations.AUTO_STYLE,
                visibility: animations.AUTO_STYLE,
                overflow: 'hidden'
            })),
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.group([animations.query('@*', animations.animateChild(), { optional: true }), animations.animate('{{duration}}' + 'ms ' + '{{delay}}' + 'ms ' + 'ease-in')])
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1e
                }
            }),
            animations.transition('1 => 0', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.group([animations.query('@*', animations.animateChild(), { optional: true }), animations.animate('{{duration}}' + 'ms ' + '{{delay}}' + 'ms ' + 'ease-out')])
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1e
                }
            })
        ]);
    }
    var expand = animations.animation(animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
        animations.style({ height: '0', visibility: 'hidden', overflow: 'hidden', easing: 'ease-out', offset: 0 }),
        animations.style({ height: animations.AUTO_STYLE, visibility: animations.AUTO_STYLE, overflow: 'hidden', easing: 'ease-out', offset: 1 })
    ])));
    var fadeInExpand = animations.animation(animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
        animations.style({ height: '0', opacity: 0, visibility: 'hidden', overflow: 'hidden', easing: 'ease-out', offset: 0 }),
        animations.style({ height: animations.AUTO_STYLE, opacity: animations.AUTO_STYLE, visibility: animations.AUTO_STYLE, overflow: 'hidden', easing: 'ease-out', offset: 1 })
    ])));
    var collapse = animations.animation(animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
        animations.style({ height: animations.AUTO_STYLE, visibility: animations.AUTO_STYLE, overflow: 'hidden', easing: 'ease-in', offset: 0 }),
        animations.style({ height: '0', visibility: 'hidden', overflow: 'hidden', easing: 'ease-in', offset: 1 })
    ])));
    var fadeOutCollapse = animations.animation(animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([
        animations.style({ height: animations.AUTO_STYLE, opacity: animations.AUTO_STYLE, visibility: animations.AUTO_STYLE, overflow: 'hidden', easing: 'ease-in', offset: 0 }),
        animations.style({ height: '0', opacity: 0, visibility: 'hidden', overflow: 'hidden', easing: 'ease-in', offset: 1 })
    ])));
    function expandOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'expandOnEnter', [
            animations.transition(':enter', animations.animation(__spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(expand)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []))), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1e
                }
            })
        ]);
    }
    function collapseOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'collapseOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(collapse)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1e
                }
            })
        ]);
    }
    function fadeInExpandOnEnterAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeInExpandOnEnter', [
            animations.transition(':enter', animations.animation(__spread([
                animations.style({ visibility: 'hidden' })
            ], (options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeInExpand)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []))), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1e
                }
            })
        ]);
    }
    function fadeOutCollapseOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'fadeOutCollapseOnLeave', [
            animations.transition(':leave', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.useAnimation(fadeOutCollapse)
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1e
                }
            })
        ]);
    }

    var DEFAULT_DURATION$1f = 200;
    function rotateAnimation(options) {
        return animations.trigger((options && options.anchor) || 'rotate', [
            animations.state('0', animations.style({
                transform: 'rotate(0deg)'
            })),
            animations.state('1', animations.style({
                transform: 'rotate(' + '{{degrees}}' + 'deg)'
            }), {
                params: {
                    degrees: (options && options.degrees) || 180
                }
            }),
            animations.transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.group([animations.query('@*', animations.animateChild(), { optional: true }), animations.animate('{{duration}}' + 'ms ' + '{{delay}}' + 'ms ' + 'ease')])
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1f
                }
            }),
            animations.transition('1 => 0', __spread((options && options.animateChildren === 'before' ? [animations.query('@*', animations.animateChild(), { optional: true })] : []), [
                animations.group(__spread([
                    animations.group([animations.query('@*', animations.animateChild(), { optional: true }), animations.animate('{{duration}}' + 'ms ' + '{{delay}}' + 'ms ' + 'ease')])
                ], (!options || !options.animateChildren || options.animateChildren === 'together'
                    ? [animations.query('@*', animations.animateChild(), { optional: true })]
                    : [])))
            ], (options && options.animateChildren === 'after' ? [animations.query('@*', animations.animateChild(), { optional: true })] : [])), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1f
                }
            })
        ]);
    }

    var hueRotate = animations.animation([
        animations.animate('{{duration}}ms {{delay}}ms', animations.keyframes([animations.style({ filter: 'hue-rotate(0deg)', offset: 0 }), animations.style({ filter: 'hue-rotate(-360deg)', offset: 1 })]))
    ]);
    var DEFAULT_DURATION$1g = 3000;
    function hueRotateAnimation(options) {
        return animations.trigger((options && options.anchor) || 'hueRotate', [
            animations.transition('0 <=> 1', animations.group([animations.query('@*', animations.animateChild(), { optional: true }), animations.useAnimation(hueRotate)]), {
                params: {
                    delay: (options && options.delay) || 0,
                    duration: (options && options.duration) || DEFAULT_DURATION$1g
                }
            })
        ]);
    }

    function animateChildrenOnLeaveAnimation(options) {
        return animations.trigger((options && options.anchor) || 'animateChildrenOnLeave', [
            animations.transition(':leave', [animations.query('@*', animations.animateChild(), { optional: true })])
        ]);
    }

    exports.animateChildrenOnLeaveAnimation = animateChildrenOnLeaveAnimation;
    exports.bounceAnimation = bounceAnimation;
    exports.bounceInAnimation = bounceInAnimation;
    exports.bounceInDownAnimation = bounceInDownAnimation;
    exports.bounceInDownOnEnterAnimation = bounceInDownOnEnterAnimation;
    exports.bounceInLeftAnimation = bounceInLeftAnimation;
    exports.bounceInLeftOnEnterAnimation = bounceInLeftOnEnterAnimation;
    exports.bounceInOnEnterAnimation = bounceInOnEnterAnimation;
    exports.bounceInRightAnimation = bounceInRightAnimation;
    exports.bounceInRightOnEnterAnimation = bounceInRightOnEnterAnimation;
    exports.bounceInUpAnimation = bounceInUpAnimation;
    exports.bounceInUpOnEnterAnimation = bounceInUpOnEnterAnimation;
    exports.bounceOnEnterAnimation = bounceOnEnterAnimation;
    exports.bounceOutAnimation = bounceOutAnimation;
    exports.bounceOutDownAnimation = bounceOutDownAnimation;
    exports.bounceOutDownOnLeaveAnimation = bounceOutDownOnLeaveAnimation;
    exports.bounceOutLeftAnimation = bounceOutLeftAnimation;
    exports.bounceOutLeftOnLeaveAnimation = bounceOutLeftOnLeaveAnimation;
    exports.bounceOutOnLeaveAnimation = bounceOutOnLeaveAnimation;
    exports.bounceOutRightAnimation = bounceOutRightAnimation;
    exports.bounceOutRightOnLeaveAnimation = bounceOutRightOnLeaveAnimation;
    exports.bounceOutUpAnimation = bounceOutUpAnimation;
    exports.bounceOutUpOnLeaveAnimation = bounceOutUpOnLeaveAnimation;
    exports.collapseAnimation = collapseAnimation;
    exports.collapseOnLeaveAnimation = collapseOnLeaveAnimation;
    exports.expandOnEnterAnimation = expandOnEnterAnimation;
    exports.fadeInAnimation = fadeInAnimation;
    exports.fadeInDownAnimation = fadeInDownAnimation;
    exports.fadeInDownBigAnimation = fadeInDownBigAnimation;
    exports.fadeInDownBigOnEnterAnimation = fadeInDownBigOnEnterAnimation;
    exports.fadeInDownOnEnterAnimation = fadeInDownOnEnterAnimation;
    exports.fadeInExpandOnEnterAnimation = fadeInExpandOnEnterAnimation;
    exports.fadeInLeftAnimation = fadeInLeftAnimation;
    exports.fadeInLeftBigAnimation = fadeInLeftBigAnimation;
    exports.fadeInLeftBigOnEnterAnimation = fadeInLeftBigOnEnterAnimation;
    exports.fadeInLeftOnEnterAnimation = fadeInLeftOnEnterAnimation;
    exports.fadeInOnEnterAnimation = fadeInOnEnterAnimation;
    exports.fadeInRightAnimation = fadeInRightAnimation;
    exports.fadeInRightBigAnimation = fadeInRightBigAnimation;
    exports.fadeInRightBigOnEnterAnimation = fadeInRightBigOnEnterAnimation;
    exports.fadeInRightOnEnterAnimation = fadeInRightOnEnterAnimation;
    exports.fadeInUpAnimation = fadeInUpAnimation;
    exports.fadeInUpBigAnimation = fadeInUpBigAnimation;
    exports.fadeInUpBigOnEnterAnimation = fadeInUpBigOnEnterAnimation;
    exports.fadeInUpOnEnterAnimation = fadeInUpOnEnterAnimation;
    exports.fadeOutAnimation = fadeOutAnimation;
    exports.fadeOutCollapseOnLeaveAnimation = fadeOutCollapseOnLeaveAnimation;
    exports.fadeOutDownAnimation = fadeOutDownAnimation;
    exports.fadeOutDownBigAnimation = fadeOutDownBigAnimation;
    exports.fadeOutDownBigOnLeaveAnimation = fadeOutDownBigOnLeaveAnimation;
    exports.fadeOutDownOnLeaveAnimation = fadeOutDownOnLeaveAnimation;
    exports.fadeOutLeftAnimation = fadeOutLeftAnimation;
    exports.fadeOutLeftBigAnimation = fadeOutLeftBigAnimation;
    exports.fadeOutLeftBigOnLeaveAnimation = fadeOutLeftBigOnLeaveAnimation;
    exports.fadeOutLeftOnLeaveAnimation = fadeOutLeftOnLeaveAnimation;
    exports.fadeOutOnLeaveAnimation = fadeOutOnLeaveAnimation;
    exports.fadeOutRightAnimation = fadeOutRightAnimation;
    exports.fadeOutRightBigAnimation = fadeOutRightBigAnimation;
    exports.fadeOutRightBigOnLeaveAnimation = fadeOutRightBigOnLeaveAnimation;
    exports.fadeOutRightOnLeaveAnimation = fadeOutRightOnLeaveAnimation;
    exports.fadeOutUpAnimation = fadeOutUpAnimation;
    exports.fadeOutUpBigAnimation = fadeOutUpBigAnimation;
    exports.fadeOutUpBigOnLeaveAnimation = fadeOutUpBigOnLeaveAnimation;
    exports.fadeOutUpOnLeaveAnimation = fadeOutUpOnLeaveAnimation;
    exports.flashAnimation = flashAnimation;
    exports.flashOnEnterAnimation = flashOnEnterAnimation;
    exports.flipAnimation = flipAnimation;
    exports.flipInXAnimation = flipInXAnimation;
    exports.flipInXOnEnterAnimation = flipInXOnEnterAnimation;
    exports.flipInYAnimation = flipInYAnimation;
    exports.flipInYOnEnterAnimation = flipInYOnEnterAnimation;
    exports.flipOnEnterAnimation = flipOnEnterAnimation;
    exports.flipOutXAnimation = flipOutXAnimation;
    exports.flipOutXOnLeaveAnimation = flipOutXOnLeaveAnimation;
    exports.flipOutYAnimation = flipOutYAnimation;
    exports.flipOutYOnLeaveAnimation = flipOutYOnLeaveAnimation;
    exports.headShakeAnimation = headShakeAnimation;
    exports.headShakeOnEnterAnimation = headShakeOnEnterAnimation;
    exports.heartBeatAnimation = heartBeatAnimation;
    exports.heartBeatOnEnterAnimation = heartBeatOnEnterAnimation;
    exports.hingeAnimation = hingeAnimation;
    exports.hingeOnLeaveAnimation = hingeOnLeaveAnimation;
    exports.hueRotateAnimation = hueRotateAnimation;
    exports.jackInTheBoxAnimation = jackInTheBoxAnimation;
    exports.jackInTheBoxOnEnterAnimation = jackInTheBoxOnEnterAnimation;
    exports.jelloAnimation = jelloAnimation;
    exports.jelloOnEnterAnimation = jelloOnEnterAnimation;
    exports.lightSpeedInAnimation = lightSpeedInAnimation;
    exports.lightSpeedInOnEnterAnimation = lightSpeedInOnEnterAnimation;
    exports.lightSpeedOutAnimation = lightSpeedOutAnimation;
    exports.lightSpeedOutOnLeaveAnimation = lightSpeedOutOnLeaveAnimation;
    exports.pulseAnimation = pulseAnimation;
    exports.pulseOnEnterAnimation = pulseOnEnterAnimation;
    exports.rollInAnimation = rollInAnimation;
    exports.rollInOnEnterAnimation = rollInOnEnterAnimation;
    exports.rollOutAnimation = rollOutAnimation;
    exports.rollOutOnLeaveAnimation = rollOutOnLeaveAnimation;
    exports.rotateAnimation = rotateAnimation;
    exports.rotateInAnimation = rotateInAnimation;
    exports.rotateInDownLeftAnimation = rotateInDownLeftAnimation;
    exports.rotateInDownLeftOnEnterAnimation = rotateInDownLeftOnEnterAnimation;
    exports.rotateInDownRightAnimation = rotateInDownRightAnimation;
    exports.rotateInDownRightOnEnterAnimation = rotateInDownRightOnEnterAnimation;
    exports.rotateInOnEnterAnimation = rotateInOnEnterAnimation;
    exports.rotateInUpLeftAnimation = rotateInUpLeftAnimation;
    exports.rotateInUpLeftOnEnterAnimation = rotateInUpLeftOnEnterAnimation;
    exports.rotateInUpRightAnimation = rotateInUpRightAnimation;
    exports.rotateInUpRightOnEnterAnimation = rotateInUpRightOnEnterAnimation;
    exports.rotateOutAnimation = rotateOutAnimation;
    exports.rotateOutDownLeftAnimation = rotateOutDownLeftAnimation;
    exports.rotateOutDownLeftOnLeaveAnimation = rotateOutDownLeftOnLeaveAnimation;
    exports.rotateOutDownRightAnimation = rotateOutDownRightAnimation;
    exports.rotateOutDownRightOnLeaveAnimation = rotateOutDownRightOnLeaveAnimation;
    exports.rotateOutOnLeaveAnimation = rotateOutOnLeaveAnimation;
    exports.rotateOutUpLeftAnimation = rotateOutUpLeftAnimation;
    exports.rotateOutUpLeftOnLeaveAnimation = rotateOutUpLeftOnLeaveAnimation;
    exports.rotateOutUpRightAnimation = rotateOutUpRightAnimation;
    exports.rotateOutUpRightOnLeaveAnimation = rotateOutUpRightOnLeaveAnimation;
    exports.rubberBandAnimation = rubberBandAnimation;
    exports.rubberBandOnEnterAnimation = rubberBandOnEnterAnimation;
    exports.shakeAnimation = shakeAnimation;
    exports.shakeOnEnterAnimation = shakeOnEnterAnimation;
    exports.slideInDownAnimation = slideInDownAnimation;
    exports.slideInDownOnEnterAnimation = slideInDownOnEnterAnimation;
    exports.slideInLeftAnimation = slideInLeftAnimation;
    exports.slideInLeftOnEnterAnimation = slideInLeftOnEnterAnimation;
    exports.slideInRightAnimation = slideInRightAnimation;
    exports.slideInRightOnEnterAnimation = slideInRightOnEnterAnimation;
    exports.slideInUpAnimation = slideInUpAnimation;
    exports.slideInUpOnEnterAnimation = slideInUpOnEnterAnimation;
    exports.slideOutDownAnimation = slideOutDownAnimation;
    exports.slideOutDownOnLeaveAnimation = slideOutDownOnLeaveAnimation;
    exports.slideOutLeftAnimation = slideOutLeftAnimation;
    exports.slideOutLeftOnLeaveAnimation = slideOutLeftOnLeaveAnimation;
    exports.slideOutRightAnimation = slideOutRightAnimation;
    exports.slideOutRightOnLeaveAnimation = slideOutRightOnLeaveAnimation;
    exports.slideOutUpAnimation = slideOutUpAnimation;
    exports.slideOutUpOnLeaveAnimation = slideOutUpOnLeaveAnimation;
    exports.swingAnimation = swingAnimation;
    exports.swingOnEnterAnimation = swingOnEnterAnimation;
    exports.tadaAnimation = tadaAnimation;
    exports.tadaOnEnterAnimation = tadaOnEnterAnimation;
    exports.wobbleAnimation = wobbleAnimation;
    exports.wobbleOnEnterAnimation = wobbleOnEnterAnimation;
    exports.zoomInAnimation = zoomInAnimation;
    exports.zoomInDownAnimation = zoomInDownAnimation;
    exports.zoomInDownOnEnterAnimation = zoomInDownOnEnterAnimation;
    exports.zoomInLeftAnimation = zoomInLeftAnimation;
    exports.zoomInLeftOnEnterAnimation = zoomInLeftOnEnterAnimation;
    exports.zoomInOnEnterAnimation = zoomInOnEnterAnimation;
    exports.zoomInRightAnimation = zoomInRightAnimation;
    exports.zoomInRightOnEnterAnimation = zoomInRightOnEnterAnimation;
    exports.zoomInUpAnimation = zoomInUpAnimation;
    exports.zoomInUpOnEnterAnimation = zoomInUpOnEnterAnimation;
    exports.zoomOutAnimation = zoomOutAnimation;
    exports.zoomOutDownAnimation = zoomOutDownAnimation;
    exports.zoomOutDownOnLeaveAnimation = zoomOutDownOnLeaveAnimation;
    exports.zoomOutLeftAnimation = zoomOutLeftAnimation;
    exports.zoomOutLeftOnLeaveAnimation = zoomOutLeftOnLeaveAnimation;
    exports.zoomOutOnLeaveAnimation = zoomOutOnLeaveAnimation;
    exports.zoomOutRightAnimation = zoomOutRightAnimation;
    exports.zoomOutRightOnLeaveAnimation = zoomOutRightOnLeaveAnimation;
    exports.zoomOutUpAnimation = zoomOutUpAnimation;
    exports.zoomOutUpOnLeaveAnimation = zoomOutUpOnLeaveAnimation;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=angular-animations.umd.js.map
