import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IBounceInUpAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 3000px
     */
    translate?: string;
}
export declare function bounceInUpAnimation(options?: IBounceInUpAnimationOptions): AnimationTriggerMetadata;
export declare function bounceInUpOnEnterAnimation(options?: IBounceInUpAnimationOptions): AnimationTriggerMetadata;
