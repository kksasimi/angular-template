import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IBounceInDownAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 3000px
     */
    translate?: string;
}
export declare function bounceInDownAnimation(options?: IBounceInDownAnimationOptions): AnimationTriggerMetadata;
export declare function bounceInDownOnEnterAnimation(options?: IBounceInDownAnimationOptions): AnimationTriggerMetadata;
