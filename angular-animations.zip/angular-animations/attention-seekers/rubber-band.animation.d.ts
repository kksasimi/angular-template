import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions, IAttentionSeekerAnimationOptions } from '../common/interfaces';
export declare function rubberBandAnimation(options?: IAttentionSeekerAnimationOptions): AnimationTriggerMetadata;
export declare function rubberBandOnEnterAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
