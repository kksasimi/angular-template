import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions, IAttentionSeekerAnimationOptions } from '../common/interfaces';
export declare function jelloAnimation(options?: IAttentionSeekerAnimationOptions): AnimationTriggerMetadata;
export declare function jelloOnEnterAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
