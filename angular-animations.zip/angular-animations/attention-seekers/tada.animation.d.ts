import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions, IAttentionSeekerAnimationOptions } from '../common/interfaces';
export declare function tadaAnimation(options?: IAttentionSeekerAnimationOptions): AnimationTriggerMetadata;
export declare function tadaOnEnterAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
