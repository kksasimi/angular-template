import { AnimationTriggerMetadata } from '@angular/animations';
import { IAttentionSeekerAnimationOptions } from '../common/interfaces';
export interface IHeartBeatAnimationOptions extends IAttentionSeekerAnimationOptions {
    /**
     * Scale factor
     *
     * Default: 1.3
     */
    scale?: number;
}
export declare function heartBeatAnimation(options?: IHeartBeatAnimationOptions): AnimationTriggerMetadata;
export declare function heartBeatOnEnterAnimation(options?: IHeartBeatAnimationOptions): AnimationTriggerMetadata;
