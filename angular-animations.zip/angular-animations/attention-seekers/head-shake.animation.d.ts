import { AnimationTriggerMetadata } from '@angular/animations';
import { IAttentionSeekerAnimationOptions } from '../common/interfaces';
export declare function headShakeAnimation(options?: IAttentionSeekerAnimationOptions): AnimationTriggerMetadata;
export declare function headShakeOnEnterAnimation(options?: IAttentionSeekerAnimationOptions): AnimationTriggerMetadata;
