import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions, IAttentionSeekerAnimationOptions } from '../common/interfaces';
export declare function flashAnimation(options?: IAttentionSeekerAnimationOptions): AnimationTriggerMetadata;
export declare function flashOnEnterAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
