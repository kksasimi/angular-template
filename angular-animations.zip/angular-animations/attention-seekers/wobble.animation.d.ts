import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions, IAttentionSeekerAnimationOptions } from '../common/interfaces';
export declare function wobbleAnimation(options?: IAttentionSeekerAnimationOptions): AnimationTriggerMetadata;
export declare function wobbleOnEnterAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
