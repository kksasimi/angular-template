import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions, IAttentionSeekerAnimationOptions } from '../common/interfaces';
export declare function bounceAnimation(options?: IAttentionSeekerAnimationOptions): AnimationTriggerMetadata;
export declare function bounceOnEnterAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
