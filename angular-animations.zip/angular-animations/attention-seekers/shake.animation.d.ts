import { AnimationTriggerMetadata } from '@angular/animations';
import { IAttentionSeekerAnimationOptions } from '../common/interfaces';
export interface IShakeAnimationOptions extends IAttentionSeekerAnimationOptions {
    /**
     * Shake size. Possible units: px, %, em, rem, vw, vh
     *
     * Default: 10px
     */
    translate?: string;
}
export declare function shakeAnimation(options?: IShakeAnimationOptions): AnimationTriggerMetadata;
export declare function shakeOnEnterAnimation(options?: IShakeAnimationOptions): AnimationTriggerMetadata;
