import { AnimationTriggerMetadata } from '@angular/animations';
import { IAttentionSeekerAnimationOptions } from '../common/interfaces';
export interface IPulseAnimationOptions extends IAttentionSeekerAnimationOptions {
    /**
     * Scale factor
     *
     * Default: 1.05
     */
    scale?: number;
}
export declare function pulseAnimation(options?: IPulseAnimationOptions): AnimationTriggerMetadata;
export declare function pulseOnEnterAnimation(options?: IPulseAnimationOptions): AnimationTriggerMetadata;
