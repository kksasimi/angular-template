import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export declare function zoomInUpAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
export declare function zoomInUpOnEnterAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
