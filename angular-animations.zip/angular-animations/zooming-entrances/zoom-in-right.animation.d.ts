import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export declare function zoomInRightAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
export declare function zoomInRightOnEnterAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
