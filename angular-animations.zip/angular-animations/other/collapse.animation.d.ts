import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export declare function collapseAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
export declare function expandOnEnterAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
export declare function collapseOnLeaveAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
export declare function fadeInExpandOnEnterAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
export declare function fadeOutCollapseOnLeaveAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
