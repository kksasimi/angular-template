import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
interface IRotateAnimationOptions extends IAnimationOptions {
    /**
     * Degrees to rotate. Default 180
     */
    degrees?: number;
}
export declare function rotateAnimation(options?: IRotateAnimationOptions): AnimationTriggerMetadata;
export {};
