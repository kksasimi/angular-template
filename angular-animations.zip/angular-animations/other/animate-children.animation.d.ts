import { AnimationTriggerMetadata } from '@angular/animations';
interface IAnimateChildrenOnLeaveOptions {
    /**
     * Name of the animation anchor that will be used in a template
     *
     * Default: animateChildrenOnLeave
     */
    anchor?: string;
}
export declare function animateChildrenOnLeaveAnimation(options?: IAnimateChildrenOnLeaveOptions): AnimationTriggerMetadata;
export {};
