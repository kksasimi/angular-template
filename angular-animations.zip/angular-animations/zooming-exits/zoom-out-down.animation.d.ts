import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export declare function zoomOutDownAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
export declare function zoomOutDownOnLeaveAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
