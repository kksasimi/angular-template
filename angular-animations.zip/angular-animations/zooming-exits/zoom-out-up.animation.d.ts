import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export declare function zoomOutUpAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
export declare function zoomOutUpOnLeaveAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
