import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export declare function zoomOutRightAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
export declare function zoomOutRightOnLeaveAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
