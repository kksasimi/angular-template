import { __spread } from 'tslib';
import { animation, animate, keyframes, style, AUTO_STYLE, trigger, transition, query, animateChild, group, useAnimation, state } from '@angular/animations';

var bounce = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: AUTO_STYLE, transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.2 }),
        style({ transform: 'translate3d(0, -30px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.4 }),
        style({ transform: 'translate3d(0, -30px, 0)', easing: 'cubic-bezier(0.755, 0.05, 0.855, 0.06)', offset: 0.43 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.755, 0.05, 0.855, 0.06)', offset: 0.53 }),
        style({ transform: 'translate3d(0, -15px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.7 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.755, 0.05, 0.855, 0.06)', offset: 0.8 }),
        style({ transform: 'translate3d(0, -4px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.9 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION = 1000;
function bounceAnimation(options) {
    return trigger((options && options.anchor) || 'bounce', [
        transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'transform-origin': 'center bottom' }),
                useAnimation(bounce)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION
            }
        })
    ]);
}
function bounceOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'bounceOnEnter', [
        transition(':enter', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ visibility: 'hidden' }),
            group(__spread([
                style({ 'transform-origin': 'center bottom' }),
                useAnimation(bounce)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION
            }
        })
    ]);
}

var flash = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: AUTO_STYLE, opacity: 1, easing: 'ease', offset: 0 }),
        style({ opacity: 0, easing: 'ease', offset: 0.25 }),
        style({ opacity: 1, easing: 'ease', offset: 0.5 }),
        style({ opacity: 0, easing: 'ease', offset: 0.75 }),
        style({ opacity: 1, easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$1 = 1000;
function flashAnimation(options) {
    return trigger((options && options.anchor) || 'flash', [
        transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(flash)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1
            }
        })
    ]);
}
function flashOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'flashOnEnter', [
        transition(':enter', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ visibility: 'hidden' }),
            group(__spread([
                useAnimation(flash)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1
            }
        })
    ]);
}

var pulse = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: AUTO_STYLE, transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 0 }),
        style({ transform: 'scale3d({{scale}}, {{scale}}, {{scale}})', easing: 'ease', offset: 0.5 }),
        style({ transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$2 = 1000;
function pulseAnimation(options) {
    return trigger((options && options.anchor) || 'pulse', [
        transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(pulse)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$2,
                scale: (options && options.scale) || 1.05
            }
        })
    ]);
}
function pulseOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'pulseOnEnter', [
        transition(':enter', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ visibility: 'hidden' }),
            group(__spread([
                useAnimation(pulse)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$2,
                scale: (options && options.scale) || 1.05
            }
        })
    ]);
}

var rubberBand = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: AUTO_STYLE, transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 0 }),
        style({ transform: 'scale3d(1.25, 0.75, 1)', easing: 'ease', offset: 0.3 }),
        style({ transform: 'scale3d(0.75, 1.25, 1)', easing: 'ease', offset: 0.4 }),
        style({ transform: 'scale3d(1.15, 0.85, 1)', easing: 'ease', offset: 0.5 }),
        style({ transform: 'scale3d(0.95, 1.05, 1)', easing: 'ease', offset: 0.65 }),
        style({ transform: 'scale3d(1.05, 0.95, 1)', easing: 'ease', offset: 0.75 }),
        style({ transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$3 = 1000;
function rubberBandAnimation(options) {
    return trigger((options && options.anchor) || 'rubberBand', [
        transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(rubberBand)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$3
            }
        })
    ]);
}
function rubberBandOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'rubberBandOnEnter', [
        transition(':enter', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ visibility: 'hidden' }),
            group(__spread([
                useAnimation(rubberBand)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$3
            }
        })
    ]);
}

var shake = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: AUTO_STYLE, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0.1 }),
        style({ transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0.2 }),
        style({ transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0.3 }),
        style({ transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0.4 }),
        style({ transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0.5 }),
        style({ transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0.6 }),
        style({ transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0.7 }),
        style({ transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0.8 }),
        style({ transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0.9 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$4 = 1000;
function shakeAnimation(options) {
    return trigger((options && options.anchor) || 'shake', [
        transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(shake)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$4,
                translate: (options && options.translate) || '10px'
            }
        })
    ]);
}
function shakeOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'shakeOnEnter', [
        transition(':enter', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ visibility: 'hidden' }),
            group(__spread([
                useAnimation(shake)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$4,
                translate: (options && options.translate) || '10px'
            }
        })
    ]);
}

var swing = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: AUTO_STYLE, transform: 'rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 0 }),
        style({ transform: 'rotate3d(0, 0, 1, 15deg)', easing: 'ease', offset: 0.2 }),
        style({ transform: 'rotate3d(0, 0, 1, -10deg)', easing: 'ease', offset: 0.4 }),
        style({ transform: 'rotate3d(0, 0, 1, 5deg)', easing: 'ease', offset: 0.6 }),
        style({ transform: 'rotate3d(0, 0, 1, -5deg)', easing: 'ease', offset: 0.8 }),
        style({ transform: 'rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$5 = 1000;
function swingAnimation(options) {
    return trigger((options && options.anchor) || 'swing', [
        transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'transform-origin': 'top center' }),
                useAnimation(swing)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$5
            }
        })
    ]);
}
function swingOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'swingOnEnter', [
        transition(':enter', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ visibility: 'hidden' }),
            group(__spread([
                style({ 'transform-origin': 'top center' }),
                useAnimation(swing)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$5
            }
        })
    ]);
}

var tada = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: AUTO_STYLE, transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 0 }),
        style({ transform: 'scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg)', easing: 'ease', offset: 0.1 }),
        style({ transform: 'scale3d(0.9, 0.9, 0.9) rotate3d(0, 0, 1, -3deg)', easing: 'ease', offset: 0.2 }),
        style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)', easing: 'ease', offset: 0.3 }),
        style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg)', easing: 'ease', offset: 0.4 }),
        style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)', easing: 'ease', offset: 0.5 }),
        style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg)', easing: 'ease', offset: 0.6 }),
        style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)', easing: 'ease', offset: 0.7 }),
        style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, -3deg)', easing: 'ease', offset: 0.8 }),
        style({ transform: 'scale3d(1.1, 1.1, 1.1) rotate3d(0, 0, 1, 3deg)', easing: 'ease', offset: 0.9 }),
        style({ transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$6 = 1000;
function tadaAnimation(options) {
    return trigger((options && options.anchor) || 'tada', [
        transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(tada)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$6
            }
        })
    ]);
}
function tadaOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'tadaOnEnter', [
        transition(':enter', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ visibility: 'hidden' }),
            group(__spread([
                useAnimation(tada)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$6
            }
        })
    ]);
}

var wobble = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: AUTO_STYLE, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg)', easing: 'ease', offset: 0.15 }),
        style({ transform: 'translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg)', easing: 'ease', offset: 0.3 }),
        style({ transform: 'translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg)', easing: 'ease', offset: 0.45 }),
        style({ transform: 'translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg)', easing: 'ease', offset: 0.6 }),
        style({ transform: 'translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg)', easing: 'ease', offset: 0.75 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$7 = 1000;
function wobbleAnimation(options) {
    return trigger((options && options.anchor) || 'wobble', [
        transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(wobble)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$7
            }
        })
    ]);
}
function wobbleOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'wobbleOnEnter', [
        transition(':enter', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ visibility: 'hidden' }),
            group(__spread([
                useAnimation(wobble)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$7
            }
        })
    ]);
}

var jello = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: AUTO_STYLE, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0.111 }),
        style({ transform: 'skewX(-12.5deg) skewY(-12.5deg)', easing: 'ease', offset: 0.222 }),
        style({ transform: 'skewX(6.25deg) skewY(6.25deg)', easing: 'ease', offset: 0.333 }),
        style({ transform: 'skewX(-3.125deg) skewY(-3.125deg)', easing: 'ease', offset: 0.444 }),
        style({ transform: 'skewX(1.5625deg) skewY(1.5625deg)', easing: 'ease', offset: 0.555 }),
        style({ transform: 'skewX(-0.78125deg) skewY(-0.78125deg)', easing: 'ease', offset: 0.666 }),
        style({ transform: 'skewX(0.390625deg) skewY(0.390625deg)', easing: 'ease', offset: 0.777 }),
        style({ transform: 'skewX(-0.1953125deg) skewY(-0.1953125deg)', easing: 'ease', offset: 0.888 }),
        style({ transform: 'skewX(0deg) skewY(0deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$8 = 1000;
function jelloAnimation(options) {
    return trigger((options && options.anchor) || 'jello', [
        transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'transform-origin': 'center' }),
                useAnimation(jello)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$8
            }
        })
    ]);
}
function jelloOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'jelloOnEnter', [
        transition(':enter', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ visibility: 'hidden' }),
            group(__spread([
                style({ 'transform-origin': 'center' }),
                useAnimation(jello)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$8
            }
        })
    ]);
}

var heartBeat = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: AUTO_STYLE, transform: 'scale(1)', easing: 'ease-in-out', offset: 0 }),
        style({ transform: 'scale({{scale}})', easing: 'ease-in-out', offset: 0.14 }),
        style({ transform: 'scale(1)', easing: 'ease-in-out', offset: 0.28 }),
        style({ transform: 'scale({{scale}})', easing: 'ease-in-out', offset: 0.42 }),
        style({ transform: 'scale(1)', easing: 'ease-in-out', offset: 0.7 })
    ]))
]);
var DEFAULT_DURATION$9 = 1300;
var DEFAULT_SCALE = 1.3;
function heartBeatAnimation(options) {
    return trigger((options && options.anchor) || 'heartBeat', [
        transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(heartBeat)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$9,
                scale: (options && options.scale) || DEFAULT_SCALE
            }
        })
    ]);
}
function heartBeatOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'heartBeatOnEnter', [
        transition(':enter', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ visibility: 'hidden' }),
            group(__spread([
                useAnimation(heartBeat)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$9,
                scale: (options && options.scale) || DEFAULT_SCALE
            }
        })
    ]);
}

var headShake = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: AUTO_STYLE, transform: 'translateX(0)', easing: 'ease-in-out', offset: 0 }),
        style({ transform: 'translateX(-6px) rotateY(-9deg)', easing: 'ease-in-out', offset: 0.065 }),
        style({ transform: 'translateX(5px) rotateY(7deg)', easing: 'ease-in-out', offset: 0.185 }),
        style({ transform: 'translateX(-3px) rotateY(-5deg)', easing: 'ease-in-out', offset: 0.315 }),
        style({ transform: 'translateX(2px) rotateY(3deg)', easing: 'ease-in-out', offset: 0.435 }),
        style({ transform: 'translateX(0)', easing: 'ease-in-out', offset: 0.5 })
    ]))
]);
var DEFAULT_DURATION$a = 1000;
function headShakeAnimation(options) {
    return trigger((options && options.anchor) || 'headShake', [
        transition("0 " + ((options && options.direction) || '<=>') + " 1", __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(headShake)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$a
            }
        })
    ]);
}
function headShakeOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'headShakeOnEnter', [
        transition(':enter', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ visibility: 'hidden' }),
            group(__spread([
                useAnimation(headShake)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$a
            }
        })
    ]);
}

var bounceIn = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'scale3d(0.3, 0.3, 0.3)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
        style({ transform: 'scale3d(1.1, 1.1, 1.1)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.2 }),
        style({ transform: 'scale3d(0.9, 0.9, 0.9)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.4 }),
        style({ transform: 'scale3d(1.03, 1.03, 1.03)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
        style({ transform: 'scale3d(0.97, 0.97, 0.97)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.8 }),
        style({ transform: 'scale3d(1, 1, 1)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
    ])),
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
        style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
        style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
    ]))
]));
var DEFAULT_DURATION$b = 750;
function bounceInAnimation(options) {
    return trigger((options && options.anchor) || 'bounceIn', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceIn)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$b
            }
        })
    ]);
}
function bounceInOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'bounceInOnEnter', [
        transition(':enter', animation(__spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceIn)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : []))), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$b
            }
        })
    ]);
}

var bounceInDown = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'translate3d(0, -{{translate}}, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
        style({ transform: 'translate3d(0, 25px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
        style({ transform: 'translate3d(0, -10px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.75 }),
        style({ transform: 'translate3d(0, 5px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.9 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
    ])),
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
        style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
        style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
    ]))
]));
var DEFAULT_DURATION$c = 1000;
function bounceInDownAnimation(options) {
    return trigger((options && options.anchor) || 'bounceInDown', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceInDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$c,
                translate: (options && options.translate) || '3000px'
            }
        })
    ]);
}
function bounceInDownOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'bounceInDownOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceInDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$c,
                translate: (options && options.translate) || '3000px'
            }
        })
    ]);
}

var bounceInLeft = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
        style({ transform: 'translate3d(25px, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
        style({ transform: 'translate3d(-10px, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.75 }),
        style({ transform: 'translate3d(5px, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.9 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
    ])),
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
        style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
        style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
    ]))
]));
var DEFAULT_DURATION$d = 1000;
function bounceInLeftAnimation(options) {
    return trigger((options && options.anchor) || 'bounceInLeft', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceInLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$d,
                translate: (options && options.translate) || '3000px'
            }
        })
    ]);
}
function bounceInLeftOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'bounceInLeftOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceInLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$d,
                translate: (options && options.translate) || '3000px'
            }
        })
    ]);
}

var bounceInRight = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'translate3d({{translate}}, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
        style({ transform: 'translate3d(-25px, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
        style({ transform: 'translate3d(10px, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.75 }),
        style({ transform: 'translate3d(-5px, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.9 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
    ])),
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
        style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
        style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
    ]))
]));
var DEFAULT_DURATION$e = 1000;
function bounceInRightAnimation(options) {
    return trigger((options && options.anchor) || 'bounceInRight', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceInRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$e,
                translate: (options && options.translate) || '3000px'
            }
        })
    ]);
}
function bounceInRightOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'bounceInRightOnEnter', [
        transition(':enter', __spread([
            // style({ background: 'red' }),
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceInRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$e,
                translate: (options && options.translate) || '3000px'
            }
        })
    ]);
}

var bounceInUp = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'translate3d(0, {{translate}}, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
        style({ transform: 'translate3d(0, -20px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
        style({ transform: 'translate3d(0, 10px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.75 }),
        style({ transform: 'translate3d(0, -5px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.9 }),
        style({ transform: 'translate3d(0, -5px, 0)', easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
    ])),
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0 }),
        style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 0.6 }),
        style({ opacity: 1, easing: 'cubic-bezier(0.215, 0.61, 0.355, 1)', offset: 1 })
    ]))
]));
var DEFAULT_DURATION$f = 1000;
function bounceInUpAnimation(options) {
    return trigger((options && options.anchor) || 'bounceInUp', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceInUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$f,
                translate: (options && options.translate) || '3000px'
            }
        })
    ]);
}
function bounceInUpOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'bounceInUpOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceInUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$f,
                translate: (options && options.translate) || '3000px'
            }
        })
    ]);
}

var bounceOut = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 0 }),
        style({ transform: 'scale3d(0.9, 0.9, 0.9)', easing: 'ease', offset: 0.2 }),
        style({ transform: 'scale3d(1.1, 1.1, 1.1)', easing: 'ease', offset: 0.5 }),
        style({ transform: 'scale3d(1.1, 1.1, 1.1)', easing: 'ease', offset: 0.55 }),
        style({ transform: 'scale3d(0.3, 0.3, 0.3)', easing: 'ease', offset: 1 })
    ])),
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, easing: 'ease', offset: 0 }),
        style({ opacity: 1, easing: 'ease', offset: 0.55 }),
        style({ opacity: 0, easing: 'ease', offset: 1 })
    ]))
]));
var DEFAULT_DURATION$g = 750;
function bounceOutAnimation(options) {
    return trigger((options && options.anchor) || 'bounceOut', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceOut)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$g
            }
        })
    ]);
}
function bounceOutOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'bounceOutOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceOut)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$g
            }
        })
    ]);
}

var bounceOutDown = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d(0, 10px, 0)', easing: 'ease', offset: 0.2 }),
        style({ transform: 'translate3d(0, -20px, 0)', easing: 'ease', offset: 0.4 }),
        style({ transform: 'translate3d(0, -20px, 0)', easing: 'ease', offset: 0.45 }),
        style({ transform: 'translate3d(0, {{translate}}, 0)', easing: 'ease', offset: 1 })
    ])),
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, easing: 'ease', offset: 0 }),
        style({ opacity: 1, easing: 'ease', offset: 0.45 }),
        style({ opacity: 0, easing: 'ease', offset: 1 })
    ]))
]));
var DEFAULT_DURATION$h = 1000;
function bounceOutDownAnimation(options) {
    return trigger((options && options.anchor) || 'bounceOutDown', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceOutDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$h,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}
function bounceOutDownOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'bounceOutDownOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceOutDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$h,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}

var bounceOutLeft = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'translate3d(20px, 0, 0)', easing: 'ease', offset: 0.2 }),
        style({ opacity: 0, transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$i = 1000;
function bounceOutLeftAnimation(options) {
    return trigger((options && options.anchor) || 'bounceOutLeft', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceOutLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$i,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}
function bounceOutLeftOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'bounceOutLeftOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceOutLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$i,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}

var bounceOutRight = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'translate3d(-20px, 0, 0)', easing: 'ease', offset: 0.2 }),
        style({ opacity: 0, transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$j = 1000;
function bounceOutRightAnimation(options) {
    return trigger((options && options.anchor) || 'bounceOutRight', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceOutRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$j,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}
function bounceOutRightOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'bounceOutRightOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceOutRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$j,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}

var bounceOutUp = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d(0, -10px, 0)', easing: 'ease', offset: 0.2 }),
        style({ transform: 'translate3d(0, 20px, 0)', easing: 'ease', offset: 0.4 }),
        style({ transform: 'translate3d(0, 20px, 0)', easing: 'ease', offset: 0.45 }),
        style({ transform: 'translate3d(0, -{{translate}}, 0)', easing: 'ease', offset: 1 })
    ])),
    animation([
        animate('{{duration}}ms {{delay}}ms', keyframes([
            style({ opacity: 1, easing: 'ease', offset: 0 }),
            style({ opacity: 1, easing: 'ease', offset: 0.45 }),
            style({ opacity: 0, easing: 'ease', offset: 1 })
        ]))
    ])
]));
var DEFAULT_DURATION$k = 1000;
function bounceOutUpAnimation(options) {
    return trigger((options && options.anchor) || 'bounceOutUp', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceOutUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$k,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}
function bounceOutUpOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'bounceOutUpOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(bounceOutUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$k,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}

var fadeIn = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([style({ visibility: 'visible', opacity: 0, easing: 'ease', offset: 0 }), style({ opacity: 1, easing: 'ease', offset: 1 })]))
]);
var DEFAULT_DURATION$l = 1000;
function fadeInAnimation(options) {
    return trigger((options && options.anchor) || 'fadeIn', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeIn)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$l
            }
        })
    ]);
}
function fadeInOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeIn)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$l
            }
        })
    ]);
}

var fadeInDown = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'translate3d(0, -{{translate}}, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$m = 1000;
function fadeInDownAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInDown', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$m,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function fadeInDownOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInDownOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$m,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var fadeInDownBig = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'translate3d(0, -{{translate}}, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$n = 1000;
function fadeInDownBigAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInDownBig', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInDownBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$n,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}
function fadeInDownBigOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInDownBigOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInDownBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$n,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}

var fadeInLeft = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$o = 1000;
function fadeInLeftAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInLeft', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$o,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function fadeInLeftOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInLeftOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$o,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var fadeInLeftBig = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$p = 1000;
function fadeInLeftBigAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInLeftBig', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInLeftBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$p,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}
function fadeInLeftBigOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInLeftBigOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInLeftBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$p,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}

var fadeInRight = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$q = 1000;
function fadeInRightAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInRight', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$q,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function fadeInRightOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInRightOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$q,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var fadeInRightBig = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$r = 1000;
function fadeInRightBigAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInRightBig', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInRightBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$r,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}
function fadeInRightBigOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInRightBigOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInRightBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$r,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}

var fadeInUp = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'translate3d(0, {{translate}}, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$s = 1000;
function fadeInUpAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInUp', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$s,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function fadeInUpOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInUpOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$s,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var fadeInUpBig = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'translate3d(0, {{translate}}, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$t = 1000;
function fadeInUpBigAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInUpBig', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInUpBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$t,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}
function fadeInUpBigOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInUpBigOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInUpBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$t,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}

var fadeOut = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([style({ opacity: 1, easing: 'ease', offset: 0 }), style({ opacity: 0, easing: 'ease', offset: 1 })]))
]);
var DEFAULT_DURATION$u = 1000;
function fadeOutAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOut', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOut)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$u
            }
        })
    ]);
}
function fadeOutOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOut)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$u
            }
        })
    ]);
}

var fadeOutDown = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'translate3d(0, {{translate}}, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$v = 1000;
function fadeOutDownAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutDown', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$v,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function fadeOutDownOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutDownOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$v,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var fadeOutDownBig = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'translate3d(0, {{translate}}, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$w = 1000;
function fadeOutDownBigAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutDownBig', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutDownBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$w,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}
function fadeOutDownBigOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutDownBigOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutDownBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$w,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}

var fadeOutLeft = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$x = 1000;
function fadeOutLeftAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutLeft', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$x,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function fadeOutLeftOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutLeftOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$x,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var fadeOutLeftBig = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$y = 1000;
function fadeOutLeftBigAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutLeftBig', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutLeftBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$y,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}
function fadeOutLeftBigOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutLeftBigOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutLeftBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$y,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}

var fadeOutRight = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$z = 1000;
function fadeOutRightAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutRight', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$z,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function fadeOutRightOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutRightOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$z,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var fadeOutRightBig = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$A = 1000;
function fadeOutRightBigAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutRightBig', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutRightBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$A,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}
function fadeOutRightBigOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutRightBigOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutRightBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$A,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}

var fadeOutUp = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'translate3d(0, -{{translate}}, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$B = 1000;
function fadeOutUpAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutUp', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$B,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function fadeOutUpOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutUpOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$B,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var fadeOutUpBig = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'translate3d(0, -{{translate}}, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$C = 1000;
function fadeOutUpBigAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutUpBig', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutUpBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$C,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}
function fadeOutUpBigOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutUpBigOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutUpBig)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$C,
                translate: (options && options.translate) || '2000px'
            }
        })
    ]);
}

var flip = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({
            transform: 'perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 0) rotate3d(0, 1, 0, -360deg)',
            easing: 'ease-out',
            offset: 0
        }),
        style({
            transform: 'perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -190deg)',
            easing: 'ease-out',
            offset: 0.4
        }),
        style({
            transform: 'perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 150px) rotate3d(0, 1, 0, -170deg)',
            easing: 'ease-out',
            offset: 0.5
        }),
        style({
            transform: 'perspective(400px) scale3d(0.95, 0.95, 0.95) translate3d(0, 0, 0) rotate3d(0, 1, 0, 0deg)',
            easing: 'ease-in',
            offset: 0.8
        }),
        style({ transform: 'perspective(400px) scale3d(1, 1, 1) translate3d(0, 0, 0) rotate3d(0, 1, 0, 0deg)', easing: 'ease-in', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$D = 1000;
function flipAnimation(options) {
    return trigger((options && options.anchor) || 'flip', [
        transition('0 <=> 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'backface-visibility': 'visible' }),
                useAnimation(flip)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$D
            }
        })
    ]);
}
function flipOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'flipOnEnter', [
        transition(':enter', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'backface-visibility': 'visible' }),
                useAnimation(flip)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$D
            }
        })
    ]);
}

var flipInX = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({
            visibility: 'visible',
            transform: 'perspective(400px) rotate3d(1, 0, 0, {{degrees}}deg)',
            opacity: 0,
            easing: 'ease-in',
            offset: 0
        }),
        style({ transform: 'perspective(400px) rotate3d(1, 0, 0, -20deg)', opacity: 0.5, easing: 'ease-in', offset: 0.4 }),
        style({ transform: 'perspective(400px) rotate3d(1, 0, 0, 10deg)', opacity: 1, easing: 'ease-in', offset: 0.6 }),
        style({ transform: 'perspective(400px) rotate3d(1, 0, 0, -5deg)', easing: 'ease', offset: 0.8 }),
        style({ transform: 'perspective(400px)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$E = 1000;
function flipInXAnimation(options) {
    return trigger((options && options.anchor) || 'flipInX', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'backface-visibility': 'visible' }),
                useAnimation(flipInX)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$E,
                degrees: (options && options.degrees) || 90
            }
        })
    ]);
}
function flipInXOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'flipInXOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'backface-visibility': 'visible' }),
                useAnimation(flipInX)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$E,
                degrees: (options && options.degrees) || 90
            }
        })
    ]);
}

var flipInY = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({
            visibility: 'visible',
            transform: 'perspective(400px) rotate3d(0, 1, 0, {{degrees}}deg)',
            opacity: 0,
            easing: 'ease-in',
            offset: 0
        }),
        style({ transform: 'perspective(400px) rotate3d(0, 1, 0, -20deg)', opacity: 0.5, easing: 'ease-in', offset: 0.4 }),
        style({ transform: 'perspective(400px) rotate3d(0, 1, 0, 10deg)', opacity: 1, easing: 'ease-in', offset: 0.6 }),
        style({ transform: 'perspective(400px) rotate3d(0, 1, 0, -5deg)', easing: 'ease', offset: 0.8 }),
        style({ transform: 'perspective(400px)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$F = 1000;
function flipInYAnimation(options) {
    return trigger((options && options.anchor) || 'flipInY', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'backface-visibility': 'visible' }),
                useAnimation(flipInY)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$F,
                degrees: (options && options.degrees) || 90
            }
        })
    ]);
}
function flipInYOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'flipInYOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'backface-visibility': 'visible' }),
                useAnimation(flipInY)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$F,
                degrees: (options && options.degrees) || 90
            }
        })
    ]);
}

var flipOutX = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'perspective(400px)', opacity: 1, easing: 'ease', offset: 0 }),
        style({ transform: 'perspective(400px) rotate3d(1, 0, 0, -20deg)', opacity: 1, easing: 'ease', offset: 0.3 }),
        style({ transform: 'perspective(400px) rotate3d(1, 0, 0, {{degrees}}deg)', opacity: 0, easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$G = 750;
function flipOutXAnimation(options) {
    return trigger((options && options.anchor) || 'flipOutX', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'backface-visibility': 'visible' }),
                useAnimation(flipOutX)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$G,
                degrees: (options && options.degrees) || 90
            }
        })
    ]);
}
function flipOutXOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'flipOutXOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'backface-visibility': 'visible' }),
                useAnimation(flipOutX)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$G,
                degrees: (options && options.degrees) || 90
            }
        })
    ]);
}

var flipOutY = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'perspective(400px)', opacity: 1, easing: 'ease', offset: 0 }),
        style({ transform: 'perspective(400px) rotate3d(0, 1, 0, -15deg)', opacity: 1, easing: 'ease', offset: 0.3 }),
        style({ transform: 'perspective(400px) rotate3d(0, 1, 0, {{degrees}}deg)', opacity: 0, easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$H = 750;
function flipOutYAnimation(options) {
    return trigger((options && options.anchor) || 'flipOutY', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'backface-visibility': 'visible' }),
                useAnimation(flipOutY)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$H,
                degrees: (options && options.degrees) || 90
            }
        })
    ]);
}
function flipOutYOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'flipOutYOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ 'backface-visibility': 'visible' }),
                useAnimation(flipOutY)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$H,
                degrees: (options && options.degrees) || 90
            }
        })
    ]);
}

var lightSpeedIn = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({
            visibility: 'visible',
            opacity: 0,
            transform: 'translate3d({{translate}}, 0, 0) skewX(-30deg)',
            easing: 'ease-out',
            offset: 0
        }),
        style({ opacity: 1, transform: 'skewX(20deg)', easing: 'ease-out', offset: 0.6 }),
        style({ opacity: 1, transform: 'skewX(-5deg)', easing: 'ease-out', offset: 0.8 }),
        style({ opacity: 1, transform: 'translate3d(0, 0, 0)', easing: 'ease-out', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$I = 1000;
function lightSpeedInAnimation(options) {
    return trigger((options && options.anchor) || 'lightSpeedIn', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(lightSpeedIn)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$I,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function lightSpeedInOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'lightSpeedInOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(lightSpeedIn)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$I,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var lightSpeedOut = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, easing: 'ease-in', offset: 0 }),
        style({ opacity: 0, transform: 'translate3d({{translate}}, 0, 0) skewX(30deg)', easing: 'ease-in', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$J = 1000;
function lightSpeedOutAnimation(options) {
    return trigger((options && options.anchor) || 'lightSpeedOut', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(lightSpeedOut)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$J,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function lightSpeedOutOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'lightSpeedOutOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(lightSpeedOut)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$J,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var rotateIn = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'rotate({{degrees}}deg)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'rotate(0deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$K = 1000;
function rotateInAnimation(options) {
    return trigger((options && options.anchor) || 'rotateIn', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'center' }),
            group(__spread([
                useAnimation(rotateIn)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$K,
                degrees: (options && options.degrees) || -200
            }
        })
    ]);
}
function rotateInOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'rotateInOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'center' }),
            group(__spread([
                useAnimation(rotateIn)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$K,
                degrees: (options && options.degrees) || -200
            }
        })
    ]);
}

var rotateInDownLeft = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$L = 1000;
function rotateInDownLeftAnimation(options) {
    return trigger((options && options.anchor) || 'rotateInDownLeft', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'left bottom' }),
            group(__spread([
                useAnimation(rotateInDownLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$L,
                degrees: (options && options.degrees) || -45
            }
        })
    ]);
}
function rotateInDownLeftOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'rotateInDownLeftOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'left bottom' }),
            group(__spread([
                useAnimation(rotateInDownLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$L,
                degrees: (options && options.degrees) || -45
            }
        })
    ]);
}

var rotateInDownRight = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$M = 1000;
function rotateInDownRightAnimation(options) {
    return trigger((options && options.anchor) || 'rotateInDownRight', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'right bottom' }),
            group(__spread([
                useAnimation(rotateInDownRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$M,
                degrees: (options && options.degrees) || 45
            }
        })
    ]);
}
function rotateInDownRightOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'rotateInDownRightOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'right bottom' }),
            group(__spread([
                useAnimation(rotateInDownRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$M,
                degrees: (options && options.degrees) || 45
            }
        })
    ]);
}

var rotateInUpLeft = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$N = 1000;
function rotateInUpLeftAnimation(options) {
    return trigger((options && options.anchor) || 'rotateInUpLeft', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'left bottom' }),
            group(__spread([
                useAnimation(rotateInUpLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$N,
                degrees: (options && options.degrees) || 45
            }
        })
    ]);
}
function rotateInUpLeftOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'rotateInUpLeftOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'left bottom' }),
            group(__spread([
                useAnimation(rotateInUpLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$N,
                degrees: (options && options.degrees) || 45
            }
        })
    ]);
}

var rotateInUpRight = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 0 }),
        style({ opacity: 1, transform: 'rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$O = 1000;
function rotateInUpRightAnimation(options) {
    return trigger((options && options.anchor) || 'rotateInUpRight', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'right bottom' }),
            group(__spread([
                useAnimation(rotateInUpRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$O,
                degrees: (options && options.degrees) || -90
            }
        })
    ]);
}
function rotateInUpRightOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'rotateInUpRightOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'right bottom' }),
            group(__spread([
                useAnimation(rotateInUpRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$O,
                degrees: (options && options.degrees) || -90
            }
        })
    ]);
}

var rotateOut = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'rotate({{degrees}}deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$P = 1000;
function rotateOutAnimation(options) {
    return trigger((options && options.anchor) || 'rotateOut', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'center' }),
            group(__spread([
                useAnimation(rotateOut)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$P,
                degrees: (options && options.degrees) || 200
            }
        })
    ]);
}
function rotateOutOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'rotateOutOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'center' }),
            group(__spread([
                useAnimation(rotateOut)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$P,
                degrees: (options && options.degrees) || 200
            }
        })
    ]);
}

var rotateOutDownLeft = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$Q = 1000;
function rotateOutDownLeftAnimation(options) {
    return trigger((options && options.anchor) || 'rotateOutDownLeft', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'left bottom' }),
            group(__spread([
                useAnimation(rotateOutDownLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$Q,
                degrees: (options && options.degrees) || 45
            }
        })
    ]);
}
function rotateOutDownLeftOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'rotateOutDownLeftOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'left bottom' }),
            group(__spread([
                useAnimation(rotateOutDownLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$Q,
                degrees: (options && options.degrees) || 45
            }
        })
    ]);
}

var rotateOutDownRight = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$R = 1000;
function rotateOutDownRightAnimation(options) {
    return trigger((options && options.anchor) || 'rotateOutDownRight', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'right bottom' }),
            group(__spread([
                useAnimation(rotateOutDownRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$R,
                degrees: (options && options.degrees) || -45
            }
        })
    ]);
}
function rotateOutDownRightOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'rotateOutDownRightOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'right bottom' }),
            group(__spread([
                useAnimation(rotateOutDownRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$R,
                degrees: (options && options.degrees) || -45
            }
        })
    ]);
}

var rotateOutUpLeft = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$S = 1000;
function rotateOutUpLeftAnimation(options) {
    return trigger((options && options.anchor) || 'rotateOutUpLeft', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'left bottom' }),
            group(__spread([
                useAnimation(rotateOutUpLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$S,
                degrees: (options && options.degrees) || -45
            }
        })
    ]);
}
function rotateOutUpLeftOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'rotateOutUpLeftOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'left bottom' }),
            group(__spread([
                useAnimation(rotateOutUpLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$S,
                degrees: (options && options.degrees) || -45
            }
        })
    ]);
}

var rotateOutUpRight = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$T = 1000;
function rotateOutUpRightAnimation(options) {
    return trigger((options && options.anchor) || 'rotateOutUpRight', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'right bottom' }),
            group(__spread([
                useAnimation(rotateOutUpRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$T,
                degrees: (options && options.degrees) || 90
            }
        })
    ]);
}
function rotateOutUpRightOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'rotateOutUpRightOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            style({ 'transform-origin': 'right bottom' }),
            group(__spread([
                useAnimation(rotateOutUpRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$T,
                degrees: (options && options.degrees) || 90
            }
        })
    ]);
}

var slideInDown = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', transform: 'translate3d(0, -{{translate}}, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$U = 1000;
function slideInDownAnimation(options) {
    return trigger((options && options.anchor) || 'slideInDown', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ visibility: 'visible' }),
                useAnimation(slideInDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$U,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function slideInDownOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'slideInDownOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(slideInDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$U,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var slideInLeft = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', transform: 'translate3d(-{{translate}}, 0, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$V = 1000;
function slideInLeftAnimation(options) {
    return trigger((options && options.anchor) || 'slideInLeft', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ visibility: 'visible' }),
                useAnimation(slideInLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$V,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function slideInLeftOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'slideInLeftOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(slideInLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$V,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var slideInRight = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', transform: 'translate3d({{translate}}, 0, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$W = 1000;
function slideInRightAnimation(options) {
    return trigger((options && options.anchor) || 'slideInRight', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ visibility: 'visible' }),
                useAnimation(slideInRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$W,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function slideInRightOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'slideInRightOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(slideInRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$W,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var slideInUp = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', transform: 'translate3d(0, {{translate}}, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$X = 1000;
function slideInUpAnimation(options) {
    return trigger((options && options.anchor) || 'slideInUp', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                style({ visibility: 'visible' }),
                useAnimation(slideInUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$X,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function slideInUpOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'slideInUpOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(slideInUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$X,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var slideOutDown = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d(0, {{translate}}, 0)', visibility: 'hidden', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$Y = 1000;
function slideOutDownAnimation(options) {
    return trigger((options && options.anchor) || 'slideOutDown', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(slideOutDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$Y,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function slideOutDownOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'slideOutDownOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(slideOutDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$Y,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var slideOutLeft = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d(-{{translate}}, 0, 0)', visibility: 'hidden', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$Z = 1000;
function slideOutLeftAnimation(options) {
    return trigger((options && options.anchor) || 'slideOutLeft', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(slideOutLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$Z,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function slideOutLeftOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'slideOutLeftOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(slideOutLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$Z,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var slideOutRight = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d({{translate}}, 0, 0)', visibility: 'hidden', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$_ = 1000;
function slideOutRightAnimation(options) {
    return trigger((options && options.anchor) || 'slideOutRight', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(slideOutRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$_,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function slideOutRightOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'slideOutRightOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(slideOutRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$_,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var slideOutUp = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'translate3d(0, 0, 0)', easing: 'ease', offset: 0 }),
        style({ transform: 'translate3d(0, -{{translate}}, 0)', visibility: 'hidden', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$$ = 1000;
function slideOutUpAnimation(options) {
    return trigger((options && options.anchor) || 'slideOutUp', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(slideOutUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$$,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function slideOutUpOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'slideOutUpOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(slideOutUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$$,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var zoomIn = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 0, easing: 'ease', offset: 0 }),
        style({ opacity: 1, easing: 'ease', offset: 0.5 }),
        style({ opacity: 1, easing: 'ease', offset: 1 })
    ])),
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ visibility: 'visible', transform: 'scale3d(0.3, 0.3, 0.3)', easing: 'ease', offset: 0 }),
        style({ transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 1 })
    ]))
]));
var DEFAULT_DURATION$10 = 1000;
function zoomInAnimation(options) {
    return trigger((options && options.anchor) || 'zoomIn', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomIn)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$10
            }
        })
    ]);
}
function zoomInOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'zoomInOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomIn)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$10
            }
        })
    ]);
}

var zoomInDown = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({
            visibility: 'visible',
            opacity: 0,
            transform: 'scale3d(0.1, 0.1, 0.1) translate3d(0, -1000px, 0)',
            easing: 'ease',
            offset: 0
        }),
        style({
            opacity: 1,
            transform: 'scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0)',
            easing: 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
            offset: 0.6
        }),
        style({ opacity: 1, transform: 'scale3d(1, 1, 1) translate3d(0, 0, 0)', easing: 'cubic-bezier(0.175, 0.885, 0.32, 1)', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$11 = 1000;
function zoomInDownAnimation(options) {
    return trigger((options && options.anchor) || 'zoomInDown', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomInDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$11
            }
        })
    ]);
}
function zoomInDownOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'zoomInDownOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomInDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$11
            }
        })
    ]);
}

var zoomInLeft = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({
            visibility: 'visible',
            opacity: 0,
            transform: 'scale3d(0.1, 0.1, 0.1) translate3d(-3000px, 0, 0)',
            easing: 'ease',
            offset: 0
        }),
        style({
            opacity: 1,
            transform: 'scale3d(0.475, 0.475, 0.475) translate3d(10px, 0, 0)',
            easing: 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
            offset: 0.6
        }),
        style({ opacity: 1, transform: 'scale3d(1, 1, 1) translate3d(0, 0, 0)', easing: 'cubic-bezier(0.175, 0.885, 0.32, 1)', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$12 = 1000;
function zoomInLeftAnimation(options) {
    return trigger((options && options.anchor) || 'zoomInLeft', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomInLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$12
            }
        })
    ]);
}
function zoomInLeftOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'zoomInLeftOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomInLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$12
            }
        })
    ]);
}

var zoomInRight = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({
            visibility: 'visible',
            opacity: 0,
            transform: 'scale3d(0.1, 0.1, 0.1) translate3d(1000px, 0, 0)',
            easing: 'ease',
            offset: 0
        }),
        style({
            opacity: 1,
            transform: 'scale3d(0.475, 0.475, 0.475) translate3d(-10px, 0, 0)',
            easing: 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
            offset: 0.6
        }),
        style({ opacity: 1, transform: 'scale3d(1, 1, 1) translate3d(0, 0, 0)', easing: 'cubic-bezier(0.175, 0.885, 0.32, 1)', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$13 = 1000;
function zoomInRightAnimation(options) {
    return trigger((options && options.anchor) || 'zoomInRight', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomInRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$13
            }
        })
    ]);
}
function zoomInRightOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'zoomInRightOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomInRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$13
            }
        })
    ]);
}

var zoomInUp = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({
            visibility: 'visible',
            opacity: 0,
            transform: 'scale3d(0.1, 0.1, 0.1) translate3d(0, 1000px, 0)',
            easing: 'ease',
            offset: 0
        }),
        style({
            opacity: 1,
            transform: 'scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0)',
            easing: 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
            offset: 0.6
        }),
        style({ opacity: 1, transform: 'scale3d(1, 1, 1) translate3d(0, 0, 0)', easing: 'cubic-bezier(0.175, 0.885, 0.32, 1)', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$14 = 1000;
function zoomInUpAnimation(options) {
    return trigger((options && options.anchor) || 'zoomInUp', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomInUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$14
            }
        })
    ]);
}
function zoomInUpOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'zoomInUpOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomInUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$14
            }
        })
    ]);
}

var zoomOut = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'scale3d(0.3, 0.3, 0.3)', easing: 'ease', offset: 0.5 }),
        style({ opacity: 0, easing: 'ease', offset: 1 })
    ])),
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ transform: 'scale3d(1, 1, 1)', easing: 'ease', offset: 0 }),
        style({ transform: 'scale3d(0.3, 0.3, 0.3)', easing: 'ease', offset: 0.5 })
    ]))
]));
var DEFAULT_DURATION$15 = 1000;
function zoomOutAnimation(options) {
    return trigger((options && options.anchor) || 'zoomOut', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomOut)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$15
            }
        })
    ]);
}
function zoomOutOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'zoomOutOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomOut)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$15
            }
        })
    ]);
}

var zoomOutDown = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({
            'transform-origin': 'center bottom',
            opacity: 1,
            transform: 'scale3d(0.475, 0.475, 0.475) translate3d(0, -60px, 0)',
            easing: 'ease',
            offset: 0.4
        }),
        style({
            'transform-origin': 'center bottom',
            opacity: 0,
            transform: 'scale3d(0.1, 0.1, 0.1) translate3d(0, 2000px, 0)',
            easing: 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
            offset: 1
        })
    ]))
]);
var DEFAULT_DURATION$16 = 1000;
function zoomOutDownAnimation(options) {
    return trigger((options && options.anchor) || 'zoomOutDown', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomOutDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$16
            }
        })
    ]);
}
function zoomOutDownOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'zoomOutDownOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomOutDown)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$16
            }
        })
    ]);
}

var zoomOutLeft = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'scale3d(0.475, 0.475, 0.475) translate3d(42px, 0, 0)', easing: 'ease', offset: 0.4 }),
        style({ opacity: 0, transform: 'scale3d(0.1, 0.1, 0.1) translate3d(-2000px, 0, 0)', easing: 'ease', offset: 1 })
    ])),
    animate('{{duration}}ms {{delay}}ms', keyframes([style({ 'transform-origin': 'center center', offset: 0 }), style({ 'transform-origin': 'left center', offset: 0.4 })]))
]));
var DEFAULT_DURATION$17 = 1000;
function zoomOutLeftAnimation(options) {
    return trigger((options && options.anchor) || 'zoomOutLeft', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomOutLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$17
            }
        })
    ]);
}
function zoomOutLeftOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'zoomOutLeftOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomOutLeft)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$17
            }
        })
    ]);
}

var zoomOutRight = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'scale3d(0.475, 0.475, 0.475) translate3d(-42px, 0, 0)', easing: 'ease', offset: 0.4 }),
        style({ opacity: 0, transform: 'scale3d(0.1, 0.1, 0.1) translate3d(2000px, 0, 0)', easing: 'ease', offset: 1 })
    ])),
    animate('{{duration}}ms {{delay}}ms', keyframes([style({ 'transform-origin': 'center center', offset: 0 }), style({ 'transform-origin': 'right center', offset: 0.4 })]))
]));
var DEFAULT_DURATION$18 = 1000;
function zoomOutRightAnimation(options) {
    return trigger((options && options.anchor) || 'zoomOutRight', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomOutRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$18
            }
        })
    ]);
}
function zoomOutRightOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'zoomOutRightOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomOutRight)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$18
            }
        })
    ]);
}

var zoomOutUp = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({
            'transform-origin': 'center bottom',
            opacity: 1,
            transform: 'scale3d(0.475, 0.475, 0.475) translate3d(0, 60px, 0)',
            easing: 'ease',
            offset: 0.4
        }),
        style({
            'transform-origin': 'center bottom',
            opacity: 0,
            transform: 'scale3d(0.1, 0.1, 0.1) translate3d(0, -2000px, 0)',
            easing: 'cubic-bezier(0.55, 0.055, 0.675, 0.19)',
            offset: 1
        })
    ]))
]);
var DEFAULT_DURATION$19 = 1000;
function zoomOutUpAnimation(options) {
    return trigger((options && options.anchor) || 'zoomOutUp', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomOutUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$19
            }
        })
    ]);
}
function zoomOutUpOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'zoomOutUpOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(zoomOutUp)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$19
            }
        })
    ]);
}

var hinge = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, 'transform-origin': 'top left', transform: 'translate3d(0, 0, 0)', easing: 'ease-in-out', offset: 0 }),
        style({ opacity: 1, 'transform-origin': 'top left', transform: 'rotate3d(0, 0, 1, 80deg)', easing: 'ease-in-out', offset: 0.2 }),
        style({ opacity: 1, 'transform-origin': 'top left', transform: 'rotate3d(0, 0, 1, 60deg)', easing: 'ease-in-out', offset: 0.4 }),
        style({ opacity: 1, 'transform-origin': 'top left', transform: 'rotate3d(0, 0, 1, 80deg)', easing: 'ease-in-out', offset: 0.6 }),
        style({ opacity: 1, 'transform-origin': 'top left', transform: 'rotate3d(0, 0, 1, 60deg)', easing: 'ease-in-out', offset: 0.8 }),
        style({ opacity: 0, 'transform-origin': 'top left', transform: 'translate3d(0, 700px, 0)', easing: 'ease-in-out', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$1a = 2000;
function hingeAnimation(options) {
    return trigger((options && options.anchor) || 'hinge', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(hinge)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1a
            }
        })
    ]);
}
function hingeOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'hingeOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(hinge)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1a
            }
        })
    ]);
}

var jackInTheBox = animation(group([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ 'transform-origin': 'center bottom', transform: 'scale(0.1) rotate(30deg)', easing: 'ease', offset: 0 }),
        style({ 'transform-origin': 'center bottom', transform: 'rotate(-10deg)', easing: 'ease', offset: 0.5 }),
        style({ 'transform-origin': 'center bottom', transform: 'rotate(3deg)', easing: 'ease', offset: 0.7 }),
        style({ 'transform-origin': 'center bottom', transform: 'scale(1)', easing: 'ease', offset: 1 })
    ])),
    animate('{{duration}}ms {{delay}}ms', keyframes([style({ visibility: 'visible', opacity: 0, offset: 0 }), style({ opacity: 1, offset: 1 })]))
]));
var DEFAULT_DURATION$1b = 1000;
function jackInTheBoxAnimation(options) {
    return trigger((options && options.anchor) || 'jackInTheBox', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(jackInTheBox)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1b
            }
        })
    ]);
}
function jackInTheBoxOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'jackInTheBoxOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(jackInTheBox)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1b
            }
        })
    ]);
}

var rollIn = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({
            visibility: 'visible',
            opacity: 0,
            transform: 'translate3d({{translate}}, 0, 0) rotate3d(0, 0, 1, {{degrees}}deg)',
            easing: 'ease',
            offset: 0
        }),
        style({ opacity: 1, transform: 'translate3d(0, 0, 0) rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$1c = 1000;
function rollInAnimation(options) {
    return trigger((options && options.anchor) || 'rollIn', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(rollIn)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1c,
                degrees: (options && options.degrees) || -120,
                translate: (options && options.translate) || '-100%'
            }
        })
    ]);
}
function rollInOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'rollInOnEnter', [
        transition(':enter', __spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(rollIn)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1c,
                degrees: (options && options.degrees) || -120,
                translate: (options && options.translate) || '-100%'
            }
        })
    ]);
}

var rollOut = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([
        style({ opacity: 1, transform: 'translate3d(0, 0, 0) rotate3d(0, 0, 1, 0deg)', easing: 'ease', offset: 0 }),
        style({ opacity: 0, transform: 'translate3d({{translate}}, 0, 0) rotate3d(0, 0, 1, {{degrees}}deg)', easing: 'ease', offset: 1 })
    ]))
]);
var DEFAULT_DURATION$1d = 1000;
function rollOutAnimation(options) {
    return trigger((options && options.anchor) || 'rollOut', [
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(rollOut)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1d,
                degrees: (options && options.degrees) || 120,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}
function rollOutOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'rollOutOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(rollOut)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1d,
                degrees: (options && options.degrees) || 120,
                translate: (options && options.translate) || '100%'
            }
        })
    ]);
}

var DEFAULT_DURATION$1e = 200;
function collapseAnimation(options) {
    return trigger((options && options.anchor) || 'collapse', [
        state('1', style({
            height: '0',
            visibility: 'hidden',
            overflow: 'hidden'
        })),
        state('0', style({
            height: AUTO_STYLE,
            visibility: AUTO_STYLE,
            overflow: 'hidden'
        })),
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                group([query('@*', animateChild(), { optional: true }), animate('{{duration}}' + 'ms ' + '{{delay}}' + 'ms ' + 'ease-in')])
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1e
            }
        }),
        transition('1 => 0', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                group([query('@*', animateChild(), { optional: true }), animate('{{duration}}' + 'ms ' + '{{delay}}' + 'ms ' + 'ease-out')])
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1e
            }
        })
    ]);
}
var expand = animation(animate('{{duration}}ms {{delay}}ms', keyframes([
    style({ height: '0', visibility: 'hidden', overflow: 'hidden', easing: 'ease-out', offset: 0 }),
    style({ height: AUTO_STYLE, visibility: AUTO_STYLE, overflow: 'hidden', easing: 'ease-out', offset: 1 })
])));
var fadeInExpand = animation(animate('{{duration}}ms {{delay}}ms', keyframes([
    style({ height: '0', opacity: 0, visibility: 'hidden', overflow: 'hidden', easing: 'ease-out', offset: 0 }),
    style({ height: AUTO_STYLE, opacity: AUTO_STYLE, visibility: AUTO_STYLE, overflow: 'hidden', easing: 'ease-out', offset: 1 })
])));
var collapse = animation(animate('{{duration}}ms {{delay}}ms', keyframes([
    style({ height: AUTO_STYLE, visibility: AUTO_STYLE, overflow: 'hidden', easing: 'ease-in', offset: 0 }),
    style({ height: '0', visibility: 'hidden', overflow: 'hidden', easing: 'ease-in', offset: 1 })
])));
var fadeOutCollapse = animation(animate('{{duration}}ms {{delay}}ms', keyframes([
    style({ height: AUTO_STYLE, opacity: AUTO_STYLE, visibility: AUTO_STYLE, overflow: 'hidden', easing: 'ease-in', offset: 0 }),
    style({ height: '0', opacity: 0, visibility: 'hidden', overflow: 'hidden', easing: 'ease-in', offset: 1 })
])));
function expandOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'expandOnEnter', [
        transition(':enter', animation(__spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(expand)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : []))), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1e
            }
        })
    ]);
}
function collapseOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'collapseOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(collapse)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1e
            }
        })
    ]);
}
function fadeInExpandOnEnterAnimation(options) {
    return trigger((options && options.anchor) || 'fadeInExpandOnEnter', [
        transition(':enter', animation(__spread([
            style({ visibility: 'hidden' })
        ], (options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeInExpand)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : []))), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1e
            }
        })
    ]);
}
function fadeOutCollapseOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'fadeOutCollapseOnLeave', [
        transition(':leave', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                useAnimation(fadeOutCollapse)
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1e
            }
        })
    ]);
}

var DEFAULT_DURATION$1f = 200;
function rotateAnimation(options) {
    return trigger((options && options.anchor) || 'rotate', [
        state('0', style({
            transform: 'rotate(0deg)'
        })),
        state('1', style({
            transform: 'rotate(' + '{{degrees}}' + 'deg)'
        }), {
            params: {
                degrees: (options && options.degrees) || 180
            }
        }),
        transition('0 => 1', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                group([query('@*', animateChild(), { optional: true }), animate('{{duration}}' + 'ms ' + '{{delay}}' + 'ms ' + 'ease')])
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1f
            }
        }),
        transition('1 => 0', __spread((options && options.animateChildren === 'before' ? [query('@*', animateChild(), { optional: true })] : []), [
            group(__spread([
                group([query('@*', animateChild(), { optional: true }), animate('{{duration}}' + 'ms ' + '{{delay}}' + 'ms ' + 'ease')])
            ], (!options || !options.animateChildren || options.animateChildren === 'together'
                ? [query('@*', animateChild(), { optional: true })]
                : [])))
        ], (options && options.animateChildren === 'after' ? [query('@*', animateChild(), { optional: true })] : [])), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1f
            }
        })
    ]);
}

var hueRotate = animation([
    animate('{{duration}}ms {{delay}}ms', keyframes([style({ filter: 'hue-rotate(0deg)', offset: 0 }), style({ filter: 'hue-rotate(-360deg)', offset: 1 })]))
]);
var DEFAULT_DURATION$1g = 3000;
function hueRotateAnimation(options) {
    return trigger((options && options.anchor) || 'hueRotate', [
        transition('0 <=> 1', group([query('@*', animateChild(), { optional: true }), useAnimation(hueRotate)]), {
            params: {
                delay: (options && options.delay) || 0,
                duration: (options && options.duration) || DEFAULT_DURATION$1g
            }
        })
    ]);
}

function animateChildrenOnLeaveAnimation(options) {
    return trigger((options && options.anchor) || 'animateChildrenOnLeave', [
        transition(':leave', [query('@*', animateChild(), { optional: true })])
    ]);
}

export { animateChildrenOnLeaveAnimation, bounceAnimation, bounceInAnimation, bounceInDownAnimation, bounceInDownOnEnterAnimation, bounceInLeftAnimation, bounceInLeftOnEnterAnimation, bounceInOnEnterAnimation, bounceInRightAnimation, bounceInRightOnEnterAnimation, bounceInUpAnimation, bounceInUpOnEnterAnimation, bounceOnEnterAnimation, bounceOutAnimation, bounceOutDownAnimation, bounceOutDownOnLeaveAnimation, bounceOutLeftAnimation, bounceOutLeftOnLeaveAnimation, bounceOutOnLeaveAnimation, bounceOutRightAnimation, bounceOutRightOnLeaveAnimation, bounceOutUpAnimation, bounceOutUpOnLeaveAnimation, collapseAnimation, collapseOnLeaveAnimation, expandOnEnterAnimation, fadeInAnimation, fadeInDownAnimation, fadeInDownBigAnimation, fadeInDownBigOnEnterAnimation, fadeInDownOnEnterAnimation, fadeInExpandOnEnterAnimation, fadeInLeftAnimation, fadeInLeftBigAnimation, fadeInLeftBigOnEnterAnimation, fadeInLeftOnEnterAnimation, fadeInOnEnterAnimation, fadeInRightAnimation, fadeInRightBigAnimation, fadeInRightBigOnEnterAnimation, fadeInRightOnEnterAnimation, fadeInUpAnimation, fadeInUpBigAnimation, fadeInUpBigOnEnterAnimation, fadeInUpOnEnterAnimation, fadeOutAnimation, fadeOutCollapseOnLeaveAnimation, fadeOutDownAnimation, fadeOutDownBigAnimation, fadeOutDownBigOnLeaveAnimation, fadeOutDownOnLeaveAnimation, fadeOutLeftAnimation, fadeOutLeftBigAnimation, fadeOutLeftBigOnLeaveAnimation, fadeOutLeftOnLeaveAnimation, fadeOutOnLeaveAnimation, fadeOutRightAnimation, fadeOutRightBigAnimation, fadeOutRightBigOnLeaveAnimation, fadeOutRightOnLeaveAnimation, fadeOutUpAnimation, fadeOutUpBigAnimation, fadeOutUpBigOnLeaveAnimation, fadeOutUpOnLeaveAnimation, flashAnimation, flashOnEnterAnimation, flipAnimation, flipInXAnimation, flipInXOnEnterAnimation, flipInYAnimation, flipInYOnEnterAnimation, flipOnEnterAnimation, flipOutXAnimation, flipOutXOnLeaveAnimation, flipOutYAnimation, flipOutYOnLeaveAnimation, headShakeAnimation, headShakeOnEnterAnimation, heartBeatAnimation, heartBeatOnEnterAnimation, hingeAnimation, hingeOnLeaveAnimation, hueRotateAnimation, jackInTheBoxAnimation, jackInTheBoxOnEnterAnimation, jelloAnimation, jelloOnEnterAnimation, lightSpeedInAnimation, lightSpeedInOnEnterAnimation, lightSpeedOutAnimation, lightSpeedOutOnLeaveAnimation, pulseAnimation, pulseOnEnterAnimation, rollInAnimation, rollInOnEnterAnimation, rollOutAnimation, rollOutOnLeaveAnimation, rotateAnimation, rotateInAnimation, rotateInDownLeftAnimation, rotateInDownLeftOnEnterAnimation, rotateInDownRightAnimation, rotateInDownRightOnEnterAnimation, rotateInOnEnterAnimation, rotateInUpLeftAnimation, rotateInUpLeftOnEnterAnimation, rotateInUpRightAnimation, rotateInUpRightOnEnterAnimation, rotateOutAnimation, rotateOutDownLeftAnimation, rotateOutDownLeftOnLeaveAnimation, rotateOutDownRightAnimation, rotateOutDownRightOnLeaveAnimation, rotateOutOnLeaveAnimation, rotateOutUpLeftAnimation, rotateOutUpLeftOnLeaveAnimation, rotateOutUpRightAnimation, rotateOutUpRightOnLeaveAnimation, rubberBandAnimation, rubberBandOnEnterAnimation, shakeAnimation, shakeOnEnterAnimation, slideInDownAnimation, slideInDownOnEnterAnimation, slideInLeftAnimation, slideInLeftOnEnterAnimation, slideInRightAnimation, slideInRightOnEnterAnimation, slideInUpAnimation, slideInUpOnEnterAnimation, slideOutDownAnimation, slideOutDownOnLeaveAnimation, slideOutLeftAnimation, slideOutLeftOnLeaveAnimation, slideOutRightAnimation, slideOutRightOnLeaveAnimation, slideOutUpAnimation, slideOutUpOnLeaveAnimation, swingAnimation, swingOnEnterAnimation, tadaAnimation, tadaOnEnterAnimation, wobbleAnimation, wobbleOnEnterAnimation, zoomInAnimation, zoomInDownAnimation, zoomInDownOnEnterAnimation, zoomInLeftAnimation, zoomInLeftOnEnterAnimation, zoomInOnEnterAnimation, zoomInRightAnimation, zoomInRightOnEnterAnimation, zoomInUpAnimation, zoomInUpOnEnterAnimation, zoomOutAnimation, zoomOutDownAnimation, zoomOutDownOnLeaveAnimation, zoomOutLeftAnimation, zoomOutLeftOnLeaveAnimation, zoomOutOnLeaveAnimation, zoomOutRightAnimation, zoomOutRightOnLeaveAnimation, zoomOutUpAnimation, zoomOutUpOnLeaveAnimation };
//# sourceMappingURL=angular-animations.js.map
