import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface ISlideOutDownAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function slideOutDownAnimation(options?: ISlideOutDownAnimationOptions): AnimationTriggerMetadata;
export declare function slideOutDownOnLeaveAnimation(options?: ISlideOutDownAnimationOptions): AnimationTriggerMetadata;
