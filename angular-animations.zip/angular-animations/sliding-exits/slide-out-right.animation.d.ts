import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface ISlideOutRightAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function slideOutRightAnimation(options?: ISlideOutRightAnimationOptions): AnimationTriggerMetadata;
export declare function slideOutRightOnLeaveAnimation(options?: ISlideOutRightAnimationOptions): AnimationTriggerMetadata;
