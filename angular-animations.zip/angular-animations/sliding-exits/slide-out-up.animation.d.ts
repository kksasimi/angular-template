import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface ISlideOutUpAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function slideOutUpAnimation(options?: ISlideOutUpAnimationOptions): AnimationTriggerMetadata;
export declare function slideOutUpOnLeaveAnimation(options?: ISlideOutUpAnimationOptions): AnimationTriggerMetadata;
