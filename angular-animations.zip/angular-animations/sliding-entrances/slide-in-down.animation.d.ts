import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface ISlideInDownAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function slideInDownAnimation(options?: ISlideInDownAnimationOptions): AnimationTriggerMetadata;
export declare function slideInDownOnEnterAnimation(options?: ISlideInDownAnimationOptions): AnimationTriggerMetadata;
