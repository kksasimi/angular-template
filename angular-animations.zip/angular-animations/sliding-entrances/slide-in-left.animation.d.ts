import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface ISlideInLeftAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function slideInLeftAnimation(options?: ISlideInLeftAnimationOptions): AnimationTriggerMetadata;
export declare function slideInLeftOnEnterAnimation(options?: ISlideInLeftAnimationOptions): AnimationTriggerMetadata;
