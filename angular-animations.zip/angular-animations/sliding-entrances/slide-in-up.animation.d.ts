import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface ISlideInUpAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function slideInUpAnimation(options?: ISlideInUpAnimationOptions): AnimationTriggerMetadata;
export declare function slideInUpOnEnterAnimation(options?: ISlideInUpAnimationOptions): AnimationTriggerMetadata;
