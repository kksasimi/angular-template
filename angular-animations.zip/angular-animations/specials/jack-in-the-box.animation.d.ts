import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export declare function jackInTheBoxAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
export declare function jackInTheBoxOnEnterAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
