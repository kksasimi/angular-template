import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IRollOutAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees at which end animation.
     *
     * Default 120
     */
    degrees?: number;
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function rollOutAnimation(options?: IRollOutAnimationOptions): AnimationTriggerMetadata;
export declare function rollOutOnLeaveAnimation(options?: IRollOutAnimationOptions): AnimationTriggerMetadata;
