import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IRollInAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees from which to start animation.
     *
     * Default -120
     */
    degrees?: number;
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: -100%
     */
    translate?: string;
}
export declare function rollInAnimation(options?: IRollInAnimationOptions): AnimationTriggerMetadata;
export declare function rollInOnEnterAnimation(options?: IRollInAnimationOptions): AnimationTriggerMetadata;
