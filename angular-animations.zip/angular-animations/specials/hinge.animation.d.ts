import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export declare function hingeAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
export declare function hingeOnLeaveAnimation(options?: IAnimationOptions): AnimationTriggerMetadata;
