import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface ILightSpeedInAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function lightSpeedInAnimation(options?: ILightSpeedInAnimationOptions): AnimationTriggerMetadata;
export declare function lightSpeedInOnEnterAnimation(options?: ILightSpeedInAnimationOptions): AnimationTriggerMetadata;
