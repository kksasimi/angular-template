import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IBounceOutUpAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 2000px
     */
    translate?: string;
}
export declare function bounceOutUpAnimation(options?: IBounceOutUpAnimationOptions): AnimationTriggerMetadata;
export declare function bounceOutUpOnLeaveAnimation(options?: IBounceOutUpAnimationOptions): AnimationTriggerMetadata;
