import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IBounceOutDownAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 2000px
     */
    translate?: string;
}
export declare function bounceOutDownAnimation(options?: IBounceOutDownAnimationOptions): AnimationTriggerMetadata;
export declare function bounceOutDownOnLeaveAnimation(options?: IBounceOutDownAnimationOptions): AnimationTriggerMetadata;
