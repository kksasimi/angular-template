import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IFlipOutYAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees at which end animation.
     *
     * Default 90
     */
    degrees?: number;
}
export declare function flipOutYAnimation(options?: IFlipOutYAnimationOptions): AnimationTriggerMetadata;
export declare function flipOutYOnLeaveAnimation(options?: IFlipOutYAnimationOptions): AnimationTriggerMetadata;
