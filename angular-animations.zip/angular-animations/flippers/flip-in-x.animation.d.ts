import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IFlipInXAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees from which to start animation.
     *
     * Default 90
     */
    degrees?: number;
}
export declare function flipInXAnimation(options?: IFlipInXAnimationOptions): AnimationTriggerMetadata;
export declare function flipInXOnEnterAnimation(options?: IFlipInXAnimationOptions): AnimationTriggerMetadata;
