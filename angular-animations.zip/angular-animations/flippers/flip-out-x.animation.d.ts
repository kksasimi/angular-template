import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IFlipOutXAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees at which end animation.
     *
     * Default 90
     */
    degrees?: number;
}
export declare function flipOutXAnimation(options?: IFlipOutXAnimationOptions): AnimationTriggerMetadata;
export declare function flipOutXOnLeaveAnimation(options?: IFlipOutXAnimationOptions): AnimationTriggerMetadata;
