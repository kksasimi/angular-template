import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IFlipInYAnimationOptions extends IAnimationOptions {
    /**
     * Angle -number of degrees from which to start animation.
     *
     * Default 90
     */
    degrees?: number;
}
export declare function flipInYAnimation(options?: IFlipInYAnimationOptions): AnimationTriggerMetadata;
export declare function flipInYOnEnterAnimation(options?: IFlipInYAnimationOptions): AnimationTriggerMetadata;
