import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IFadeInDownAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function fadeInDownAnimation(options?: IFadeInDownAnimationOptions): AnimationTriggerMetadata;
export declare function fadeInDownOnEnterAnimation(options?: IFadeInDownAnimationOptions): AnimationTriggerMetadata;
