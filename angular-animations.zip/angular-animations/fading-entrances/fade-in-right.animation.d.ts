import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IFadeInRightgAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function fadeInRightAnimation(options?: IFadeInRightgAnimationOptions): AnimationTriggerMetadata;
export declare function fadeInRightOnEnterAnimation(options?: IFadeInRightgAnimationOptions): AnimationTriggerMetadata;
