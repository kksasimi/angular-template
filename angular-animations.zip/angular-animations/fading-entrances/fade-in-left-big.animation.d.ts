import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IFadeInLeftBigAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 2000px
     */
    translate?: string;
}
export declare function fadeInLeftBigAnimation(options?: IFadeInLeftBigAnimationOptions): AnimationTriggerMetadata;
export declare function fadeInLeftBigOnEnterAnimation(options?: IFadeInLeftBigAnimationOptions): AnimationTriggerMetadata;
