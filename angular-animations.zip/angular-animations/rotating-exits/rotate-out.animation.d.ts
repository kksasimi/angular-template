import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IRotateOutAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees at which end animation.
     *
     * Default 200
     */
    degrees?: number;
}
export declare function rotateOutAnimation(options?: IRotateOutAnimationOptions): AnimationTriggerMetadata;
export declare function rotateOutOnLeaveAnimation(options?: IRotateOutAnimationOptions): AnimationTriggerMetadata;
