import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IRotateOutUpLeftAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees at which end animation.
     *
     * Default -45
     */
    degrees?: number;
}
export declare function rotateOutUpLeftAnimation(options?: IRotateOutUpLeftAnimationOptions): AnimationTriggerMetadata;
export declare function rotateOutUpLeftOnLeaveAnimation(options?: IRotateOutUpLeftAnimationOptions): AnimationTriggerMetadata;
