import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IRotateOutUpRightAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees at which end animation.
     *
     * Default 90
     */
    degrees?: number;
}
export declare function rotateOutUpRightAnimation(options?: IRotateOutUpRightAnimationOptions): AnimationTriggerMetadata;
export declare function rotateOutUpRightOnLeaveAnimation(options?: IRotateOutUpRightAnimationOptions): AnimationTriggerMetadata;
