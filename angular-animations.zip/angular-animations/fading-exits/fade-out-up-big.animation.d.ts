import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IFadeOutUpBigAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 2000px
     */
    translate?: string;
}
export declare function fadeOutUpBigAnimation(options?: IFadeOutUpBigAnimationOptions): AnimationTriggerMetadata;
export declare function fadeOutUpBigOnLeaveAnimation(options?: IFadeOutUpBigAnimationOptions): AnimationTriggerMetadata;
