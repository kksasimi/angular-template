import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IFadeOutLeftAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function fadeOutLeftAnimation(options?: IFadeOutLeftAnimationOptions): AnimationTriggerMetadata;
export declare function fadeOutLeftOnLeaveAnimation(options?: IFadeOutLeftAnimationOptions): AnimationTriggerMetadata;
