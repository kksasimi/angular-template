import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IFadeOutUpAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function fadeOutUpAnimation(options?: IFadeOutUpAnimationOptions): AnimationTriggerMetadata;
export declare function fadeOutUpOnLeaveAnimation(options?: IFadeOutUpAnimationOptions): AnimationTriggerMetadata;
