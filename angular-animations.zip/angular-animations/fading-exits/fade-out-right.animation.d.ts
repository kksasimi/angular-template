import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IFadeOutRightAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function fadeOutRightAnimation(options?: IFadeOutRightAnimationOptions): AnimationTriggerMetadata;
export declare function fadeOutRightOnLeaveAnimation(options?: IFadeOutRightAnimationOptions): AnimationTriggerMetadata;
