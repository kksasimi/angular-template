import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IFadeOutDownAnimationOptions extends IAnimationOptions {
    /**
     * Translate, possible units: px, %, em, rem, vw, vh
     *
     * Default: 100%
     */
    translate?: string;
}
export declare function fadeOutDownAnimation(options?: IFadeOutDownAnimationOptions): AnimationTriggerMetadata;
export declare function fadeOutDownOnLeaveAnimation(options?: IFadeOutDownAnimationOptions): AnimationTriggerMetadata;
