import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IRotateInUpRightAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees from which to start animation.
     *
     * Default -90
     */
    degrees?: number;
}
export declare function rotateInUpRightAnimation(options?: IRotateInUpRightAnimationOptions): AnimationTriggerMetadata;
export declare function rotateInUpRightOnEnterAnimation(options?: IRotateInUpRightAnimationOptions): AnimationTriggerMetadata;
