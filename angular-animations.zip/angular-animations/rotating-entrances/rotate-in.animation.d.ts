import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IRotateInAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees from which to start animation.
     *
     * Default -200
     */
    degrees?: number;
}
export declare function rotateInAnimation(options?: IRotateInAnimationOptions): AnimationTriggerMetadata;
export declare function rotateInOnEnterAnimation(options?: IRotateInAnimationOptions): AnimationTriggerMetadata;
