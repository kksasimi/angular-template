import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IRotateInDownRightAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees from which to start animation.
     *
     * Default 45
     */
    degrees?: number;
}
export declare function rotateInDownRightAnimation(options?: IRotateInDownRightAnimationOptions): AnimationTriggerMetadata;
export declare function rotateInDownRightOnEnterAnimation(options?: IRotateInDownRightAnimationOptions): AnimationTriggerMetadata;
