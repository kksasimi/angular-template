import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IRotateInDownLeftAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees from which to start animation.
     *
     * Default -45
     */
    degrees?: number;
}
export declare function rotateInDownLeftAnimation(options?: IRotateInDownLeftAnimationOptions): AnimationTriggerMetadata;
export declare function rotateInDownLeftOnEnterAnimation(options?: IRotateInDownLeftAnimationOptions): AnimationTriggerMetadata;
