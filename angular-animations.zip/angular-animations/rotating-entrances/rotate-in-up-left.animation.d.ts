import { AnimationTriggerMetadata } from '@angular/animations';
import { IAnimationOptions } from '../common/interfaces';
export interface IRotateInUpLeftAnimationOptions extends IAnimationOptions {
    /**
     * Angle - number of degrees from which to start animation.
     *
     * Default 45
     */
    degrees?: number;
}
export declare function rotateInUpLeftAnimation(options?: IRotateInUpLeftAnimationOptions): AnimationTriggerMetadata;
export declare function rotateInUpLeftOnEnterAnimation(options?: IRotateInUpLeftAnimationOptions): AnimationTriggerMetadata;
